import { db } from './index.ts';
import { groups } from './schema.ts';
import { eq, and } from 'drizzle-orm';

export interface GroupRecord {
  id: string;
  userId: string;
  jid: string;
  name: string;
  isExcluded: boolean;
  membersCount: number;
  tags?: string[] | null;
}

export async function getUserGroups(userId: string) {
  try {
    return await db.select().from(groups).where(eq(groups.userId, userId));
  } catch (error) {
    console.error('Database query getUserGroups failed:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}

export async function upsertGroup(group: GroupRecord) {
  try {
    const result = await db.insert(groups)
      .values({
        id: group.id,
        userId: group.userId,
        jid: group.jid,
        name: group.name,
        isExcluded: group.isExcluded,
        membersCount: group.membersCount,
        tags: group.tags || null,
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: groups.id,
        set: {
          jid: group.jid,
          name: group.name,
          isExcluded: group.isExcluded,
          membersCount: group.membersCount,
          tags: group.tags || null,
          updatedAt: new Date(),
        },
      })
      .returning();

    return result[0];
  } catch (error) {
    console.error('Database query upsertGroup failed:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}

export async function deleteUserGroup(groupId: string, userId: string) {
  try {
    await db.delete(groups).where(and(eq(groups.id, groupId), eq(groups.userId, userId)));
    return { success: true };
  } catch (error) {
    console.error('Database query deleteUserGroup failed:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}
