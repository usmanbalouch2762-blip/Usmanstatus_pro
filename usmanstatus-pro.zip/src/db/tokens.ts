import { db } from './index.ts';
import { tokens } from './schema.ts';
import { eq, and } from 'drizzle-orm';

export interface TokenEntity {
  id: string;
  userId: string;
  token: string;
  label?: string | null;
  issuedTo?: string | null;
  role: string;
  usageLimit: number;
  usedCount: number;
  status: string;
  createdAt: string;
  expiresAt?: string | null;
}

export async function getUserTokens(userId: string) {
  try {
    return await db.select().from(tokens).where(eq(tokens.userId, userId));
  } catch (error) {
    console.error('Database query getUserTokens failed:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}

export async function upsertToken(tokenItem: TokenEntity) {
  try {
    const result = await db.insert(tokens)
      .values({
        id: tokenItem.id,
        userId: tokenItem.userId,
        token: tokenItem.token,
        label: tokenItem.label || null,
        issuedTo: tokenItem.issuedTo || null,
        role: tokenItem.role,
        usageLimit: tokenItem.usageLimit,
        usedCount: tokenItem.usedCount,
        status: tokenItem.status,
        createdAt: tokenItem.createdAt,
        expiresAt: tokenItem.expiresAt || null,
      })
      .onConflictDoUpdate({
        target: tokens.id,
        set: {
          token: tokenItem.token,
          label: tokenItem.label || null,
          issuedTo: tokenItem.issuedTo || null,
          role: tokenItem.role,
          usageLimit: tokenItem.usageLimit,
          usedCount: tokenItem.usedCount,
          status: tokenItem.status,
          expiresAt: tokenItem.expiresAt || null,
        },
      })
      .returning();

    return result[0];
  } catch (error) {
    console.error('Database query upsertToken failed:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}

export async function deleteUserToken(tokenId: string, userId: string) {
  try {
    await db.delete(tokens).where(and(eq(tokens.id, tokenId), eq(tokens.userId, userId)));
    return { success: true };
  } catch (error) {
    console.error('Database query deleteUserToken failed:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}
