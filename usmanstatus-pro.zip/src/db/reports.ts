import { db } from './index.ts';
import { dmReports } from './schema.ts';
import { eq } from 'drizzle-orm';

export interface DMReportRecord {
  id: string;
  userId: string;
  date: string;
  time: string;
  recipientPhone: string;
  totalStatusesSent: number;
  groupsReached: number;
  viewsRecorded: number;
  repliesReceived: number;
  successRate: number;
  rawReportText?: string | null;
}

export async function getUserReports(userId: string) {
  try {
    return await db.select().from(dmReports).where(eq(dmReports.userId, userId));
  } catch (error) {
    console.error('Database query getUserReports failed:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}

export async function insertDMReport(report: DMReportRecord) {
  try {
    const result = await db.insert(dmReports)
      .values({
        id: report.id,
        userId: report.userId,
        date: report.date,
        time: report.time,
        recipientPhone: report.recipientPhone,
        totalStatusesSent: report.totalStatusesSent,
        groupsReached: report.groupsReached,
        viewsRecorded: report.viewsRecorded,
        repliesReceived: report.repliesReceived,
        successRate: report.successRate,
        rawReportText: report.rawReportText || null,
      })
      .returning();

    return result[0];
  } catch (error) {
    console.error('Database query insertDMReport failed:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}
