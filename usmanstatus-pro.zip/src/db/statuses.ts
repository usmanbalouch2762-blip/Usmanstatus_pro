import { db } from './index.ts';
import { statuses } from './schema.ts';
import { eq, and } from 'drizzle-orm';

export interface StatusRecord {
  id: string;
  userId: string;
  type: string;
  content: string;
  status: string;
  backgroundColor?: string | null;
  textColor?: string | null;
  fontFamily?: string | null;
  mediaUrl?: string | null;
  mediaCaption?: string | null;
  scheduledFor?: string | null;
  createdAt: string;
  viewCount: number;
  totalDelivered: number;
  totalTargeted: number;
  targetGroupJids?: string[] | null;
  dmReportSent?: boolean;
}

export async function getUserStatuses(userId: string) {
  try {
    return await db.select().from(statuses).where(eq(statuses.userId, userId));
  } catch (error) {
    console.error('Database query getUserStatuses failed:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}

export async function upsertStatus(statusItem: StatusRecord) {
  try {
    const result = await db.insert(statuses)
      .values({
        id: statusItem.id,
        userId: statusItem.userId,
        type: statusItem.type,
        content: statusItem.content,
        status: statusItem.status,
        backgroundColor: statusItem.backgroundColor || null,
        textColor: statusItem.textColor || null,
        fontFamily: statusItem.fontFamily || null,
        mediaUrl: statusItem.mediaUrl || null,
        mediaCaption: statusItem.mediaCaption || null,
        scheduledFor: statusItem.scheduledFor || null,
        createdAt: statusItem.createdAt,
        viewCount: statusItem.viewCount || 0,
        totalDelivered: statusItem.totalDelivered || 0,
        totalTargeted: statusItem.totalTargeted || 0,
        targetGroupJids: statusItem.targetGroupJids || null,
        dmReportSent: statusItem.dmReportSent ?? true,
      })
      .onConflictDoUpdate({
        target: statuses.id,
        set: {
          content: statusItem.content,
          status: statusItem.status,
          backgroundColor: statusItem.backgroundColor || null,
          textColor: statusItem.textColor || null,
          fontFamily: statusItem.fontFamily || null,
          mediaUrl: statusItem.mediaUrl || null,
          mediaCaption: statusItem.mediaCaption || null,
          scheduledFor: statusItem.scheduledFor || null,
          viewCount: statusItem.viewCount || 0,
          totalDelivered: statusItem.totalDelivered || 0,
          totalTargeted: statusItem.totalTargeted || 0,
          targetGroupJids: statusItem.targetGroupJids || null,
          dmReportSent: statusItem.dmReportSent ?? true,
        },
      })
      .returning();

    return result[0];
  } catch (error) {
    console.error('Database query upsertStatus failed:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}

export async function deleteUserStatus(statusId: string, userId: string) {
  try {
    await db.delete(statuses).where(and(eq(statuses.id, statusId), eq(statuses.userId, userId)));
    return { success: true };
  } catch (error) {
    console.error('Database query deleteUserStatus failed:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}
