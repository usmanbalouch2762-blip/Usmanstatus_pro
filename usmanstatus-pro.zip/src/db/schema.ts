import { pgTable, serial, text, integer, boolean, timestamp, jsonb } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

// Users table (Firebase Auth UID as unique identifier)
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(),
  email: text('email').notNull(),
  displayName: text('display_name'),
  createdAt: timestamp('created_at').defaultNow(),
});

// WhatsApp Groups table
export const groups = pgTable('groups', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull(),
  jid: text('jid').notNull(),
  name: text('name').notNull(),
  isExcluded: boolean('is_excluded').default(false).notNull(),
  membersCount: integer('members_count').default(0).notNull(),
  tags: jsonb('tags').$type<string[]>(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// WhatsApp Statuses table
export const statuses = pgTable('statuses', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull(),
  type: text('type').notNull(), // 'text' | 'image' | 'video' | 'audio'
  content: text('content').notNull(),
  status: text('status').notNull(), // 'posted' | 'scheduled' | 'failed' | 'sending'
  backgroundColor: text('background_color'),
  textColor: text('text_color'),
  fontFamily: text('font_family'),
  mediaUrl: text('media_url'),
  mediaCaption: text('media_caption'),
  scheduledFor: text('scheduled_for'),
  createdAt: text('created_at').notNull(),
  viewCount: integer('view_count').default(0).notNull(),
  totalDelivered: integer('total_delivered').default(0).notNull(),
  totalTargeted: integer('total_targeted').default(0).notNull(),
  targetGroupJids: jsonb('target_group_jids').$type<string[]>(),
  dmReportSent: boolean('dm_report_sent').default(true),
});

// DM Reports table
export const dmReports = pgTable('dm_reports', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull(),
  date: text('date').notNull(),
  time: text('time').notNull(),
  recipientPhone: text('recipient_phone').notNull(),
  totalStatusesSent: integer('total_statuses_sent').default(0).notNull(),
  groupsReached: integer('groups_reached').default(0).notNull(),
  viewsRecorded: integer('views_recorded').default(0).notNull(),
  repliesReceived: integer('replies_received').default(0).notNull(),
  successRate: integer('success_rate').default(100).notNull(),
  rawReportText: text('raw_report_text'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Access Tokens table
export const tokens = pgTable('tokens', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull(),
  token: text('token').notNull(),
  label: text('label'),
  issuedTo: text('issued_to'),
  role: text('role').default('user').notNull(), // 'user' | 'admin'
  usageLimit: integer('usage_limit').default(100).notNull(),
  usedCount: integer('used_count').default(0).notNull(),
  status: text('status').default('active').notNull(), // 'active' | 'exhausted' | 'revoked'
  createdAt: text('created_at').notNull(),
  expiresAt: text('expires_at'),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  groups: many(groups),
  statuses: many(statuses),
  dmReports: many(dmReports),
  tokens: many(tokens),
}));
