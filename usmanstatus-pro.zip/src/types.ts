export interface WhatsAppGroup {
  id: string;
  jid: string;
  name: string;
  membersCount: number;
  isExcluded: boolean;
  isPinned: boolean;
  tags: string[];
  lastStatusAt?: string;
  canPost: boolean;
  unreadCount?: number;
}

export type StatusMediaType = 'text' | 'image' | 'video' | 'audio';

export interface WhatsAppStatus {
  id: string;
  type: StatusMediaType;
  content: string; // text body or caption
  mediaUrl?: string;
  mediaName?: string;
  audioDuration?: string;
  backgroundColor: string;
  textColor: string;
  fontStyle: 'sans' | 'serif' | 'mono' | 'bold' | 'handwriting';
  targetType: 'all' | 'specific' | 'single';
  targetGroupJids: string[];
  excludedGroupJids: string[];
  createdAt: string;
  scheduledFor?: string;
  recurrence?: 'once' | 'daily' | 'weekly';
  status: 'posted' | 'scheduled' | 'failed' | 'sending';
  viewCount: number;
  totalDelivered: number;
  totalTargeted: number;
  dmReportSent: boolean;
}

export interface HourlyEngagementPoint {
  hour: string; // e.g. "09:00"
  hourNum: number;
  views: number;
  reach: number;
  replies: number;
  peakStatusTitle?: string;
}

export interface DayEngagementData {
  date: string; // e.g. "2026-08-28"
  dayName: string; // e.g. "Today (Fri)"
  totalViews: number;
  totalReach: number;
  peakHour: string;
  hourly: HourlyEngagementPoint[];
}

export interface DMReport {
  id: string;
  date: string;
  time: string;
  recipientPhone: string;
  totalStatusesSent: number;
  groupsReached: number;
  viewsRecorded: number;
  repliesReceived: number;
  successRate: number;
  rawReportText: string;
}

export interface ColorPreset {
  id: string;
  name: string;
  hex: string;
  textColor: string;
}

export interface TokenRecord {
  id: string;
  token: string;
  label: string;
  issuedTo: string;
  role: 'user' | 'admin';
  usageLimit: number;
  usedCount: number;
  status: 'active' | 'exhausted' | 'revoked';
  createdAt: string;
  expiresAt: string;
}

export interface UserSession {
  token: string;
  role: 'user' | 'admin';
  userName: string;
  userPhone: string;
  isConnected: boolean;
  connectedAt: string;
  batteryLevel: number;
  waWebVersion: string;
  statusQuotasRemaining: number;
  maxQuotas: number;
}

