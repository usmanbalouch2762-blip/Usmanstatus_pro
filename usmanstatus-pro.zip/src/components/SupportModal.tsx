import React, { useState } from 'react';
import { X, MessageSquare, Send, CheckCircle2, Phone, Mail, HelpCircle } from 'lucide-react';

interface SupportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SupportModal: React.FC<SupportModalProps> = ({ isOpen, onClose }) => {
  const [submitted, setSubmitted] = useState(false);
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message) return;
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setSubject('');
      setMessage('');
      onClose();
    }, 2200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 md:p-8 shadow-2xl border border-gray-100 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-4 border-b border-gray-100 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-brand-light text-brand flex items-center justify-center">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900">UsmanStatus Support</h3>
              <p className="text-xs text-gray-500">Fast assistance for WhatsApp session & token inquiries</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-gray-700 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="text-center py-8">
            <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-3">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h4 className="text-lg font-bold text-gray-900 mb-1">Ticket Submitted Successfully</h4>
            <p className="text-xs text-gray-500">
              Our engineering team will respond to your connected WhatsApp number or email within 15 minutes.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">Issue Category</label>
              <select 
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg border border-gray-200 text-xs focus:outline-none focus:ring-2 focus:ring-brand/40 focus:border-brand"
              >
                <option value="">Select a topic...</option>
                <option value="token">Token Redemption / Invalid Key</option>
                <option value="session">WhatsApp QR Code & Session Linking</option>
                <option value="broadcast">Group JID Exclusions & Broadcasting</option>
                <option value="reports">Daily DM Report Timing</option>
                <option value="enterprise">Custom Multi-Account Deployment</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">Your WhatsApp Number or Email</label>
              <input 
                type="text" 
                placeholder="+1 (555) 000-0000 or user@example.com" 
                className="w-full px-3.5 py-2.5 rounded-lg border border-gray-200 text-xs focus:outline-none focus:ring-2 focus:ring-brand/40 focus:border-brand"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">Describe your question</label>
              <textarea 
                rows={4}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Detail any group JIDs, token codes, or error logs..." 
                className="w-full px-3.5 py-2.5 rounded-lg border border-gray-200 text-xs focus:outline-none focus:ring-2 focus:ring-brand/40 focus:border-brand"
                required
              ></textarea>
            </div>

            <div className="bg-gray-50 p-3 rounded-xl border border-gray-100 flex items-center justify-between text-xs text-gray-500">
              <span className="flex items-center gap-1.5"><Phone className="w-3.5 h-3.5 text-brand" /> +1 (555) 019-2834</span>
              <span className="flex items-center gap-1.5"><Mail className="w-3.5 h-3.5 text-brand" /> support@usmanstatus.pro</span>
            </div>

            <button 
              type="submit"
              className="w-full bg-brand hover:bg-brand-dark text-white font-semibold py-3 rounded-lg text-xs flex items-center justify-center gap-2 transition-colors shadow-sm"
            >
              <Send className="w-3.5 h-3.5" /> Submit Support Request
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
