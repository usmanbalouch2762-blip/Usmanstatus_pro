import React, { useState } from 'react';
import { 
  Users, Search, ShieldCheck, ShieldAlert, Plus, 
  Trash2, RefreshCw, CheckCircle2, AlertTriangle, Filter, Copy, Check,
  Upload, FileSpreadsheet, Sparkles, Download
} from 'lucide-react';
import { WhatsAppGroup } from '../types';
import { BulkGroupImporterModal } from './BulkGroupImporterModal';

interface GroupsManagerProps {
  groups: WhatsAppGroup[];
  onToggleExclude: (groupId: string) => void;
  onAddGroup: (group: Omit<WhatsAppGroup, 'id'>) => void;
  onBulkAddGroups?: (newGroups: Omit<WhatsAppGroup, 'id'>[]) => void;
  onSyncGroups: () => void;
}

export const GroupsManager: React.FC<GroupsManagerProps> = ({
  groups,
  onToggleExclude,
  onAddGroup,
  onBulkAddGroups,
  onSyncGroups,
}) => {
  const [search, setSearch] = useState('');
  const [tagFilter, setTagFilter] = useState<string>('all');
  const [isAdding, setIsAdding] = useState(false);
  const [isBulkOpen, setIsBulkOpen] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');
  const [newGroupJid, setNewGroupJid] = useState('');
  const [newGroupMembers, setNewGroupMembers] = useState(150);
  const [newGroupTag, setNewGroupTag] = useState('VIP');
  const [copiedJid, setCopiedJid] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [importSuccessMessage, setImportSuccessMessage] = useState<string | null>(null);

  const filteredGroups = groups.filter(g => {
    const matchesSearch = g.name.toLowerCase().includes(search.toLowerCase()) || 
                          g.jid.toLowerCase().includes(search.toLowerCase());
    const matchesTag = tagFilter === 'all' || g.tags.includes(tagFilter);
    return matchesSearch && matchesTag;
  });

  const handleCopyJid = (jid: string) => {
    navigator.clipboard.writeText(jid);
    setCopiedJid(jid);
    setTimeout(() => setCopiedJid(null), 2000);
  };

  const handleSyncClick = () => {
    setIsSyncing(true);
    setTimeout(() => {
      onSyncGroups();
      setIsSyncing(false);
    }, 1200);
  };

  const handleCreateGroup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGroupName || !newGroupJid) return;
    
    let formattedJid = newGroupJid.trim();
    if (!formattedJid.includes('@g.us')) {
      formattedJid = `${formattedJid.replace(/[^0-9]/g, '')}@g.us`;
    }

    onAddGroup({
      name: newGroupName,
      jid: formattedJid,
      membersCount: Number(newGroupMembers) || 50,
      isExcluded: false,
      isPinned: false,
      tags: [newGroupTag],
      canPost: true,
      lastStatusAt: 'Just now',
    });

    setIsAdding(false);
    setNewGroupName('');
    setNewGroupJid('');
  };

  const handleBulkImport = (newGroups: Omit<WhatsAppGroup, 'id'>[]) => {
    if (onBulkAddGroups) {
      onBulkAddGroups(newGroups);
    } else {
      newGroups.forEach(g => onAddGroup(g));
    }
    setImportSuccessMessage(`Successfully bulk imported ${newGroups.length} WhatsApp groups!`);
    setTimeout(() => setImportSuccessMessage(null), 5000);
  };

  const allTags = Array.from(new Set(groups.flatMap(g => g.tags)));
  const activeCount = groups.filter(g => !g.isExcluded).length;
  const excludedCount = groups.filter(g => g.isExcluded).length;

  return (
    <div className="bg-white rounded-2xl p-6 md:p-8 shadow-[0_4px_25px_-5px_rgba(0,0,0,0.05)] border border-gray-100">
      {/* Top Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-gray-100 mb-6">
        <div>
          <h2 className="text-xl font-bold text-gray-900 tracking-tight flex items-center gap-2">
            <Users className="w-5 h-5 text-brand" />
            <span>Connected WhatsApp Groups & JID Directory</span>
          </h2>
          <p className="text-xs text-gray-500 mt-0.5">
            Manage target WhatsApp groups, bulk upload CSV lists, configure exclusions, and inspect protocol JIDs
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={handleSyncClick}
            disabled={isSyncing}
            className="px-3.5 py-2 rounded-xl bg-gray-50 hover:bg-gray-100 text-gray-700 border border-gray-200 text-xs font-semibold flex items-center gap-1.5 transition"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-brand ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Syncing WA Socket...' : 'Sync Groups'}</span>
          </button>

          {/* Bulk Import CSV Button */}
          <button
            type="button"
            onClick={() => setIsBulkOpen(true)}
            className="px-3.5 py-2 rounded-xl bg-brand-light hover:bg-brand/15 text-brand border border-brand/20 text-xs font-bold flex items-center gap-1.5 transition shadow-xs"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Bulk Upload CSV / JIDs</span>
          </button>

          {/* Single Add Group Button */}
          <button
            onClick={() => setIsAdding(true)}
            className="px-4 py-2 rounded-xl bg-brand hover:bg-brand-dark text-white text-xs font-bold flex items-center gap-1.5 transition shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Add Single JID</span>
          </button>
        </div>
      </div>

      {/* Success Notification Banner */}
      {importSuccessMessage && (
        <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{importSuccessMessage}</span>
        </div>
      )}

      {/* Summary KPI Badges */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        <div className="bg-gray-50 p-3 rounded-xl border border-gray-200/70">
          <span className="text-[11px] text-gray-500 font-medium">Total Groups</span>
          <div className="text-lg font-bold text-gray-900">{groups.length}</div>
        </div>
        <div className="bg-emerald-50/70 p-3 rounded-xl border border-emerald-200/70">
          <span className="text-[11px] text-emerald-700 font-medium">Active in Broadcast</span>
          <div className="text-lg font-bold text-emerald-900">{activeCount}</div>
        </div>
        <div className="bg-rose-50/70 p-3 rounded-xl border border-rose-200/70">
          <span className="text-[11px] text-rose-700 font-medium">Excluded Targets</span>
          <div className="text-lg font-bold text-rose-900">{excludedCount}</div>
        </div>
        <div className="bg-purple-50/70 p-3 rounded-xl border border-purple-200/70">
          <span className="text-[11px] text-purple-700 font-medium">Total Reach Potential</span>
          <div className="text-lg font-bold text-purple-900">
            {groups.reduce((acc, g) => acc + (g.isExcluded ? 0 : g.membersCount), 0).toLocaleString()}
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mb-6">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search group name or JID (@g.us)..."
            className="w-full pl-9 pr-4 py-2 rounded-xl border border-gray-200 text-xs focus:outline-none focus:ring-2 focus:ring-brand/40 focus:border-brand"
          />
        </div>

        {/* Tag Filters */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
          <span className="text-[11px] text-gray-400 mr-1 flex items-center gap-1">
            <Filter className="w-3 h-3" /> Tag:
          </span>
          <button
            onClick={() => setTagFilter('all')}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition ${
              tagFilter === 'all'
                ? 'bg-brand text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            All ({groups.length})
          </button>
          {allTags.map(tag => (
            <button
              key={tag}
              onClick={() => setTagFilter(tag)}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition ${
                tagFilter === tag
                  ? 'bg-brand text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {tag}
            </button>
          ))}
        </div>
      </div>

      {/* Group Directory Table */}
      <div className="overflow-x-auto rounded-xl border border-gray-200/80">
        <table className="w-full text-left text-xs">
          <thead className="bg-gray-50/90 text-gray-500 font-bold uppercase tracking-wider text-[10px] border-b border-gray-200">
            <tr>
              <th className="py-3.5 px-4">Group Name</th>
              <th className="py-3.5 px-4">WhatsApp JID Address</th>
              <th className="py-3.5 px-4">Members</th>
              <th className="py-3.5 px-4">Tags</th>
              <th className="py-3.5 px-4">Broadcast Status</th>
              <th className="py-3.5 px-4 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {filteredGroups.map(group => (
              <tr 
                key={group.id} 
                className={`hover:bg-gray-50/80 transition-colors ${
                  group.isExcluded ? 'bg-rose-50/30' : ''
                }`}
              >
                <td className="py-3.5 px-4 font-semibold text-gray-900">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-brand-light text-brand font-bold flex items-center justify-center text-[10px]">
                      {group.name.slice(0, 2).toUpperCase()}
                    </div>
                    <span>{group.name}</span>
                  </div>
                </td>

                <td className="py-3.5 px-4 font-mono text-[11px] text-gray-600">
                  <div className="flex items-center gap-1.5">
                    <span>{group.jid}</span>
                    <button
                      onClick={() => handleCopyJid(group.jid)}
                      className="text-gray-400 hover:text-brand transition"
                      title="Copy JID"
                    >
                      {copiedJid === group.jid ? (
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </td>

                <td className="py-3.5 px-4 text-gray-600 font-medium">
                  {group.membersCount.toLocaleString()} members
                </td>

                <td className="py-3.5 px-4">
                  <div className="flex flex-wrap gap-1">
                    {group.tags.map(t => (
                      <span key={t} className="px-2 py-0.5 rounded text-[10px] font-semibold bg-gray-100 text-gray-600">
                        {t}
                      </span>
                    ))}
                  </div>
                </td>

                <td className="py-3.5 px-4">
                  {group.isExcluded ? (
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-600 bg-rose-50 px-2.5 py-1 rounded-full border border-rose-200">
                      <ShieldAlert className="w-3 h-3" /> Excluded from Broadcasts
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                      <ShieldCheck className="w-3 h-3" /> Active in Broadcast
                    </span>
                  )}
                </td>

                <td className="py-3.5 px-4 text-right">
                  <button
                    onClick={() => onToggleExclude(group.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                      group.isExcluded
                        ? 'bg-emerald-100 hover:bg-emerald-200 text-emerald-800'
                        : 'bg-rose-100 hover:bg-rose-200 text-rose-800'
                    }`}
                  >
                    {group.isExcluded ? 'Include Group' : 'Exclude Group'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Bulk Importer Modal */}
      <BulkGroupImporterModal
        isOpen={isBulkOpen}
        onClose={() => setIsBulkOpen(false)}
        existingGroups={groups}
        onImportGroups={handleBulkImport}
      />

      {/* Add Single Group Modal */}
      {isAdding && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-gray-100">
            <h3 className="text-lg font-bold text-gray-900 mb-1">Add WhatsApp Group JID</h3>
            <p className="text-xs text-gray-500 mb-4">
              Enter the group name and WhatsApp protocol JID (ending in @g.us)
            </p>

            <form onSubmit={handleCreateGroup} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Group Display Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Usman Flash Deals Alpha"
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs focus:outline-none focus:ring-2 focus:ring-brand/40"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">WhatsApp Group JID</label>
                <input
                  type="text"
                  required
                  placeholder="120363028391823912@g.us"
                  value={newGroupJid}
                  onChange={(e) => setNewGroupJid(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-brand/40"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Estimated Members</label>
                  <input
                    type="number"
                    value={newGroupMembers}
                    onChange={(e) => setNewGroupMembers(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Primary Tag</label>
                  <select
                    value={newGroupTag}
                    onChange={(e) => setNewGroupTag(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs focus:outline-none"
                  >
                    <option value="VIP">VIP</option>
                    <option value="Clients">Clients</option>
                    <option value="Wholesale">Wholesale</option>
                    <option value="Finance">Finance</option>
                    <option value="Community">Community</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="px-4 py-2 text-xs font-semibold text-gray-600 hover:bg-gray-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-brand hover:bg-brand-dark rounded-lg shadow-sm"
                >
                  Add Group
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
