import React, { useState, useRef } from 'react';
import { 
  Upload, FileText, CheckCircle2, AlertCircle, Trash2, 
  Download, X, ArrowRight, ShieldCheck, Sparkles, Filter, RefreshCw, FileSpreadsheet
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { WhatsAppGroup } from '../types';

interface BulkGroupImporterModalProps {
  isOpen: boolean;
  onClose: () => void;
  existingGroups: WhatsAppGroup[];
  onImportGroups: (newGroups: Omit<WhatsAppGroup, 'id'>[]) => void;
}

interface ParsedGroupItem {
  id: string;
  name: string;
  jid: string;
  membersCount: number;
  tag: string;
  isExcluded: boolean;
  isValid: boolean;
  error?: string;
  isDuplicate: boolean;
}

export const BulkGroupImporterModal: React.FC<BulkGroupImporterModalProps> = ({
  isOpen,
  onClose,
  existingGroups,
  onImportGroups,
}) => {
  const [importMode, setImportMode] = useState<'upload' | 'paste'>('upload');
  const [pasteText, setPasteText] = useState('');
  const [parsedItems, setParsedItems] = useState<ParsedGroupItem[]>([]);
  const [defaultTag, setDefaultTag] = useState('Bulk-Imported');
  const [defaultExcluded, setDefaultExcluded] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const existingJids = new Set(existingGroups.map(g => g.jid.toLowerCase()));

  const parseRawLines = (content: string) => {
    const lines = content.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
    const results: ParsedGroupItem[] = [];

    lines.forEach((line, index) => {
      // Ignore header line if present
      if (index === 0 && (line.toLowerCase().includes('jid') || line.toLowerCase().includes('group name'))) {
        return;
      }

      let name = '';
      let jid = '';
      let members = Math.floor(Math.random() * 400) + 120;
      let tag = defaultTag;

      if (line.includes(',')) {
        // CSV parsing
        const parts = line.split(',').map(p => p.trim().replace(/^["']|["']$/g, ''));
        if (parts.length >= 2) {
          name = parts[0];
          jid = parts[1];
          if (parts[2] && !isNaN(Number(parts[2]))) members = Number(parts[2]);
          if (parts[3]) tag = parts[3];
        } else {
          jid = parts[0];
        }
      } else if (line.includes(':') || line.includes('-')) {
        // Name : JID or Name - JID
        const separator = line.includes(':') ? ':' : '-';
        const parts = line.split(separator).map(p => p.trim());
        name = parts[0];
        jid = parts[1];
      } else {
        // Plain JID or numeric ID
        jid = line;
      }

      // Format JID correctly with @g.us
      let cleanJid = jid.trim().replace(/\s+/g, '');
      if (!cleanJid.includes('@g.us')) {
        const numericOnly = cleanJid.replace(/[^0-9]/g, '');
        if (numericOnly.length >= 8) {
          cleanJid = `${numericOnly}@g.us`;
        }
      }

      const isValid = cleanJid.endsWith('@g.us') && cleanJid.length >= 12;
      const isDuplicate = existingJids.has(cleanJid.toLowerCase()) || results.some(r => r.jid.toLowerCase() === cleanJid.toLowerCase());

      if (!name) {
        name = isValid ? `Group ${cleanJid.slice(0, 8)}...` : `Imported Group #${index + 1}`;
      }

      results.push({
        id: `parsed-${Date.now()}-${index}`,
        name,
        jid: cleanJid,
        membersCount: members,
        tag,
        isExcluded: defaultExcluded,
        isValid,
        error: !isValid ? 'Invalid WhatsApp group JID format (must end in @g.us)' : isDuplicate ? 'Duplicate JID (already exists)' : undefined,
        isDuplicate,
      });
    });

    setParsedItems(results);
  };

  const handleFileUpload = (file: File) => {
    setFileName(file.name);
    setIsProcessing(true);
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      parseRawLines(text);
      setIsProcessing(false);
    };
    reader.readAsText(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  const handlePasteProcess = () => {
    if (!pasteText.trim()) return;
    setIsProcessing(true);
    parseRawLines(pasteText);
    setIsProcessing(false);
  };

  const handleRemoveItem = (id: string) => {
    setParsedItems(prev => prev.filter(item => item.id !== id));
  };

  const handleToggleExcludeItem = (id: string) => {
    setParsedItems(prev => prev.map(item => {
      if (item.id === id) {
        return { ...item, isExcluded: !item.isExcluded };
      }
      return item;
    }));
  };

  const handleTagChange = (id: string, newTag: string) => {
    setParsedItems(prev => prev.map(item => {
      if (item.id === id) {
        return { ...item, tag: newTag };
      }
      return item;
    }));
  };

  const handleDownloadSampleCsv = () => {
    const sampleCsvContent = `Group Name,JID Address,Members Count,Category Tag\n"Alpha Wholesalers Direct",120363091827364519@g.us,580,Wholesale\n"Tech Innovators Club",120363991827461928@g.us,320,VIP\n"Crypto Arbitrage Leads",120363884719203912@g.us,950,Finance\n"Dubai Real Estate Investors",120363774819201948@g.us,410,RealEstate\n"Ecommerce Dropship Scale",120363110293847561@g.us,890,E-com`;
    
    const blob = new Blob([sampleCsvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'whatsapp_groups_import_template.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const validNewItems = parsedItems.filter(item => item.isValid && !item.isDuplicate);

  const handleCommitImport = () => {
    if (validNewItems.length === 0) return;

    const formattedGroups: Omit<WhatsAppGroup, 'id'>[] = validNewItems.map(item => ({
      name: item.name,
      jid: item.jid,
      membersCount: item.membersCount,
      isExcluded: item.isExcluded,
      isPinned: false,
      tags: [item.tag || defaultTag],
      canPost: true,
      lastStatusAt: 'Just imported',
    }));

    onImportGroups(formattedGroups);
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 }
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-gray-100 overflow-hidden">
        
        {/* Header */}
        <div className="px-6 py-5 border-b border-gray-100 flex items-center justify-between bg-[#fbfcff]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-brand-light text-brand flex items-center justify-center">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-gray-900 flex items-center gap-2">
                <span>Bulk Upload WhatsApp Group JIDs</span>
                <span className="text-[11px] font-semibold bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full border border-emerald-200">
                  CSV & Plain Text Supported
                </span>
              </h3>
              <p className="text-xs text-gray-500">
                Batch import dozens of WhatsApp group protocol addresses into your broadcast directory
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-gray-100 text-gray-400 hover:text-gray-700 flex items-center justify-center transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          
          {/* Mode Switcher & Sample Download */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-gray-50 p-3 rounded-xl border border-gray-200/80">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setImportMode('upload')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition ${
                  importMode === 'upload'
                    ? 'bg-brand text-white shadow-xs'
                    : 'text-gray-600 hover:bg-gray-200/70'
                }`}
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                <span>Upload CSV / TXT</span>
              </button>
              
              <button
                type="button"
                onClick={() => setImportMode('paste')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition ${
                  importMode === 'paste'
                    ? 'bg-brand text-white shadow-xs'
                    : 'text-gray-600 hover:bg-gray-200/70'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Paste Raw List</span>
              </button>
            </div>

            <button
              type="button"
              onClick={handleDownloadSampleCsv}
              className="text-xs text-brand hover:text-brand-dark font-semibold flex items-center gap-1.5 hover:underline"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download CSV Template (.csv)</span>
            </button>
          </div>

          {/* Import Method Area */}
          {importMode === 'upload' ? (
            <div
              onDragOver={(e) => { e.preventDefault(); setDragActive(true); }}
              onDragLeave={() => setDragActive(false)}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition flex flex-col items-center justify-center ${
                dragActive
                  ? 'border-brand bg-brand-light/40'
                  : 'border-gray-300 hover:border-brand bg-gray-50/50 hover:bg-gray-50'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv,.txt"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files?.[0]) handleFileUpload(e.target.files[0]);
                }}
              />
              <div className="w-12 h-12 rounded-2xl bg-white shadow-sm border border-gray-200 flex items-center justify-center text-brand mb-3">
                <Upload className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-gray-800 mb-1">
                {fileName ? `Loaded: ${fileName}` : 'Choose CSV or Text File, or Drag & Drop'}
              </h4>
              <p className="text-xs text-gray-400 max-w-sm">
                Supports standard comma-separated values (Name, JID, Members, Tag) or plain lines of WhatsApp @g.us JIDs
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              <label className="block text-xs font-bold text-gray-700">
                Paste WhatsApp Group JIDs (one per line or CSV formatted):
              </label>
              <textarea
                rows={5}
                value={pasteText}
                onChange={(e) => setPasteText(e.target.value)}
                placeholder={`Usman Tech VIP, 120363028391823912@g.us, 480, VIP\nEcommerce Direct, 120363198234871920@g.us, 900, Wholesale\n120363384729104829@g.us\n120363019283746510@g.us`}
                className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-brand/40"
              />
              <button
                type="button"
                onClick={handlePasteProcess}
                className="px-4 py-2 bg-brand hover:bg-brand-dark text-white rounded-lg text-xs font-bold transition shadow-xs flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Parse Pasted Entries ({pasteText.split('\n').filter(Boolean).length} lines)</span>
              </button>
            </div>
          )}

          {/* Configuration Defaults */}
          {parsedItems.length > 0 && (
            <div className="p-3.5 bg-gray-50 rounded-xl border border-gray-200 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block font-bold text-gray-700 mb-1">Apply Tag to All:</label>
                <select
                  value={defaultTag}
                  onChange={(e) => {
                    const tag = e.target.value;
                    setDefaultTag(tag);
                    setParsedItems(prev => prev.map(p => ({ ...p, tag })));
                  }}
                  className="w-full px-2.5 py-1.5 bg-white border border-gray-200 rounded-lg text-xs focus:outline-none"
                >
                  <option value="Bulk-Imported">Bulk-Imported</option>
                  <option value="VIP">VIP</option>
                  <option value="Wholesale">Wholesale</option>
                  <option value="Clients">Clients</option>
                  <option value="Marketing">Marketing</option>
                  <option value="Finance">Finance</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-gray-700 mb-1">Initial Broadcast State:</label>
                <div className="flex items-center gap-3 pt-1">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      name="defaultEx"
                      checked={!defaultExcluded}
                      onChange={() => {
                        setDefaultExcluded(false);
                        setParsedItems(prev => prev.map(p => ({ ...p, isExcluded: false })));
                      }}
                      className="text-brand focus:ring-brand"
                    />
                    <span className="text-emerald-700 font-semibold">Active in Broadcasts</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      name="defaultEx"
                      checked={defaultExcluded}
                      onChange={() => {
                        setDefaultExcluded(true);
                        setParsedItems(prev => prev.map(p => ({ ...p, isExcluded: true })));
                      }}
                      className="text-brand focus:ring-brand"
                    />
                    <span className="text-rose-600 font-semibold">Excluded</span>
                  </label>
                </div>
              </div>
            </div>
          )}

          {/* Parsed Results Verification Table */}
          {parsedItems.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-gray-800">
                  Verification & Staging ({validNewItems.length} valid new groups ready)
                </span>
                <span className="text-gray-500">
                  {parsedItems.filter(i => !i.isValid || i.isDuplicate).length} flagged / skipped
                </span>
              </div>

              <div className="overflow-x-auto max-h-56 rounded-xl border border-gray-200">
                <table className="w-full text-left text-xs">
                  <thead className="bg-gray-50 text-gray-500 font-bold uppercase tracking-wider text-[10px] border-b border-gray-200">
                    <tr>
                      <th className="py-2 px-3">Group Name</th>
                      <th className="py-2 px-3">WhatsApp JID</th>
                      <th className="py-2 px-3">Members</th>
                      <th className="py-2 px-3">Tag</th>
                      <th className="py-2 px-3">Status</th>
                      <th className="py-2 px-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {parsedItems.map((item) => (
                      <tr key={item.id} className={`hover:bg-gray-50 ${!item.isValid || item.isDuplicate ? 'bg-rose-50/40' : ''}`}>
                        <td className="py-2 px-3 font-semibold text-gray-900 max-w-[140px] truncate">
                          {item.name}
                        </td>
                        <td className="py-2 px-3 font-mono text-[11px] text-gray-600">
                          {item.jid}
                        </td>
                        <td className="py-2 px-3 text-gray-500">
                          {item.membersCount}
                        </td>
                        <td className="py-2 px-3">
                          <span className="bg-gray-100 text-gray-700 px-2 py-0.5 rounded text-[10px] font-semibold">
                            {item.tag}
                          </span>
                        </td>
                        <td className="py-2 px-3">
                          {item.isDuplicate ? (
                            <span className="text-[10px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                              Duplicate JID
                            </span>
                          ) : !item.isValid ? (
                            <span className="text-[10px] font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                              Invalid @g.us
                            </span>
                          ) : (
                            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 flex items-center gap-1 w-fit">
                              <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Ready
                            </span>
                          )}
                        </td>
                        <td className="py-2 px-3 text-right">
                          <button
                            type="button"
                            onClick={() => handleRemoveItem(item.id)}
                            className="p-1 text-gray-400 hover:text-rose-600 rounded transition"
                            title="Remove row"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-100 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-gray-600 hover:bg-gray-200 rounded-xl transition"
          >
            Cancel
          </button>

          <button
            type="button"
            disabled={validNewItems.length === 0}
            onClick={handleCommitImport}
            className="px-5 py-2.5 bg-brand hover:bg-brand-dark disabled:bg-gray-300 disabled:cursor-not-allowed text-white text-xs font-bold rounded-xl flex items-center gap-2 shadow-sm transition active:scale-95"
          >
            <span>Import {validNewItems.length} Groups into Directory</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
