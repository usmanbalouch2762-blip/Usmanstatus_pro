import React, { useState } from 'react';
import { 
  Clock, Calendar, Send, Trash2, Edit3, CheckCircle2, 
  AlertCircle, Users, Sparkles, RefreshCw, Repeat
} from 'lucide-react';
import { WhatsAppStatus } from '../types';

interface ScheduledQueueManagerProps {
  scheduledStatuses: WhatsAppStatus[];
  onDispatchNow: (statusId: string) => void;
  onCancelScheduled: (statusId: string) => void;
  onReschedule: (statusId: string, newTime: string) => void;
}

export const ScheduledQueueManager: React.FC<ScheduledQueueManagerProps> = ({
  scheduledStatuses,
  onDispatchNow,
  onCancelScheduled,
  onReschedule,
}) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newScheduleValue, setNewScheduleValue] = useState('');

  if (scheduledStatuses.length === 0) {
    return (
      <div className="bg-gray-50/70 rounded-2xl p-8 text-center border border-gray-200/80">
        <div className="w-12 h-12 rounded-2xl bg-white shadow-xs border border-gray-200 flex items-center justify-center text-gray-400 mx-auto mb-3">
          <Clock className="w-6 h-6" />
        </div>
        <h4 className="text-sm font-bold text-gray-800 mb-1">No Scheduled Broadcasts in Queue</h4>
        <p className="text-xs text-gray-500 max-w-sm mx-auto">
          Use the Status Composer date/time scheduler to queue statuses for peak viewing hours (e.g. 8:00 PM).
        </p>
      </div>
    );
  }

  const handleStartEdit = (status: WhatsAppStatus) => {
    setEditingId(status.id);
    setNewScheduleValue(status.scheduledFor || '');
  };

  const handleSaveEdit = (statusId: string) => {
    if (newScheduleValue) {
      onReschedule(statusId, newScheduleValue);
    }
    setEditingId(null);
  };

  const calculateTimeRemaining = (scheduledFor?: string) => {
    if (!scheduledFor) return 'Pending trigger';
    const target = new Date(scheduledFor).getTime();
    const now = Date.now();
    const diff = target - now;

    if (isNaN(target)) return scheduledFor;
    if (diff <= 0) return 'Ready to dispatch';

    const hours = Math.floor(diff / (1000 * 60 * 60));
    const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

    if (hours > 24) {
      const days = Math.floor(hours / 24);
      return `In ${days} day${days > 1 ? 's' : ''} ${hours % 24}h`;
    }
    return `In ${hours}h ${mins}m`;
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-xs font-bold text-gray-700 uppercase tracking-wider flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5 text-brand" />
          Scheduled Queue ({scheduledStatuses.length} Pending)
        </span>
        <span className="text-[11px] text-gray-400">
          Auto-dispatches via Baileys Multi-Device Protocol
        </span>
      </div>

      <div className="grid grid-cols-1 gap-3">
        {scheduledStatuses.map((st) => (
          <div
            key={st.id}
            className="p-4 rounded-xl border border-brand/20 bg-gradient-to-r from-brand-light/30 via-white to-white shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition hover:border-brand/40"
          >
            {/* Status Preview details */}
            <div className="flex items-start gap-3">
              <div
                className="w-10 h-10 rounded-xl shrink-0 flex items-center justify-center text-white text-xs font-bold shadow-xs"
                style={{ backgroundColor: st.backgroundColor || '#7356bf' }}
              >
                {st.type.slice(0, 2).toUpperCase()}
              </div>

              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs font-bold text-gray-900 line-clamp-1">
                    {st.content ? st.content.slice(0, 45) + (st.content.length > 45 ? '...' : '') : '(Media Story)'}
                  </span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-brand/10 text-brand border border-brand/20">
                    {st.type.toUpperCase()}
                  </span>
                  {st.recurrence && st.recurrence !== 'once' && (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-700 flex items-center gap-1">
                      <Repeat className="w-3 h-3" /> {st.recurrence}
                    </span>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-3 text-xs text-gray-500">
                  <span className="flex items-center gap-1 font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                    <Calendar className="w-3 h-3 text-emerald-600" />
                    {st.scheduledFor ? new Date(st.scheduledFor).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' }) : 'Scheduled'}
                  </span>

                  <span className="text-[11px] font-medium text-brand">
                    ⏳ {calculateTimeRemaining(st.scheduledFor)}
                  </span>

                  <span className="text-[11px] text-gray-400">
                    Target: {st.targetGroupJids?.length || 0} groups
                  </span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2 shrink-0">
              {editingId === st.id ? (
                <div className="flex items-center gap-1.5">
                  <input
                    type="datetime-local"
                    value={newScheduleValue}
                    onChange={(e) => setNewScheduleValue(e.target.value)}
                    className="px-2 py-1 border border-brand rounded text-xs focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => handleSaveEdit(st.id)}
                    className="px-2.5 py-1 bg-brand text-white text-xs font-bold rounded"
                  >
                    Save
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditingId(null)}
                    className="px-2 py-1 text-gray-500 hover:bg-gray-100 text-xs rounded"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={() => handleStartEdit(st)}
                    className="p-2 text-gray-500 hover:text-brand hover:bg-brand-light rounded-lg transition"
                    title="Reschedule timestamp"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={() => onDispatchNow(st.id)}
                    className="px-3 py-1.5 bg-brand hover:bg-brand-dark text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition shadow-xs"
                    title="Broadcast now immediately"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Post Now</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onCancelScheduled(st.id)}
                    className="p-2 text-gray-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                    title="Cancel scheduled broadcast"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
