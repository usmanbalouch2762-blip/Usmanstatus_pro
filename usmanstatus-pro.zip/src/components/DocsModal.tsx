import React, { useState } from 'react';
import { X, BookOpen, Terminal, Code2, Copy, Check, Info } from 'lucide-react';

interface DocsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DocsModal: React.FC<DocsModalProps> = ({ isOpen, onClose }) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  if (!isOpen) return null;

  const copyCode = (code: string, index: number) => {
    navigator.clipboard.writeText(code);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-2xl max-w-3xl w-full p-6 md:p-8 shadow-2xl border border-gray-100 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-4 border-b border-gray-100 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-brand-light text-brand flex items-center justify-center">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900">UsmanStatus Pro Documentation</h3>
              <p className="text-xs text-gray-500">API syntax, JID definitions & WhatsApp group status specifications</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-gray-700 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-6 text-sm text-gray-600">
          <div>
            <h4 className="font-bold text-gray-900 mb-2 flex items-center gap-2">
              <Info className="w-4 h-4 text-brand" /> What is a WhatsApp Group JID?
            </h4>
            <p className="text-xs leading-relaxed text-gray-600 mb-3">
              In WhatsApp protocol, individual contacts end in <code className="bg-gray-100 text-brand px-1.5 py-0.5 rounded font-mono text-[11px]">@s.whatsapp.net</code>, whereas WhatsApp Groups always end in <code className="bg-gray-100 text-brand px-1.5 py-0.5 rounded font-mono text-[11px]">@g.us</code> (e.g., <code className="bg-gray-100 text-gray-800 px-1.5 py-0.5 rounded font-mono text-[11px]">120363028391823912@g.us</code>).
            </p>
            <div className="bg-gray-900 text-gray-100 p-3.5 rounded-xl font-mono text-xs relative flex items-center justify-between">
              <span>120363028391823912@g.us</span>
              <button 
                onClick={() => copyCode('120363028391823912@g.us', 0)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                {copiedIndex === 0 ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div>
            <h4 className="font-bold text-gray-900 mb-2 flex items-center gap-2">
              <Terminal className="w-4 h-4 text-brand" /> WhatsApp Status Broadcast Protocol Payload
            </h4>
            <p className="text-xs leading-relaxed text-gray-600 mb-3">
              UsmanStatus Pro packages the raw Baileys/WPPConnect protobuf status payload with custom broadcast targets without spamming group chat feeds:
            </p>
            <div className="bg-gray-900 text-emerald-400 p-4 rounded-xl font-mono text-xs overflow-x-auto relative">
              <pre>{`POST /api/v1/group-status/broadcast
Headers:
  Authorization: Bearer USMAN-PRO-DEMO-2026
  Content-Type: application/json

Body:
{
  "type": "text",
  "content": "Special weekend alert for all partners!",
  "backgroundColor": "#7356bf",
  "fontStyle": "bold",
  "targets": ["all"],
  "excludeJids": ["120363847192038471@g.us"],
  "sendDmReport": true
}`}</pre>
              <button 
                onClick={() => copyCode(`{\n  "type": "text",\n  "content": "Special weekend alert for all partners!",\n  "backgroundColor": "#7356bf",\n  "fontStyle": "bold",\n  "targets": ["all"],\n  "excludeJids": ["120363847192038471@g.us"],\n  "sendDmReport": true\n}`, 1)}
                className="absolute top-3 right-3 text-gray-400 hover:text-white transition-colors"
              >
                {copiedIndex === 1 ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div>
            <h4 className="font-bold text-gray-900 mb-2 flex items-center gap-2">
              <Code2 className="w-4 h-4 text-brand" /> Supported Status Formats
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-3 bg-gray-50 border border-gray-200 rounded-xl">
                <span className="font-bold text-gray-900 block mb-1">Text Status</span>
                <span className="text-gray-500 text-[11px]">Up to 700 chars with 18 WhatsApp background colors</span>
              </div>
              <div className="p-3 bg-gray-50 border border-gray-200 rounded-xl">
                <span className="font-bold text-gray-900 block mb-1">Image Status</span>
                <span className="text-gray-500 text-[11px]">JPG, PNG, WebP up to 16MB with rich custom captions</span>
              </div>
              <div className="p-3 bg-gray-50 border border-gray-200 rounded-xl">
                <span className="font-bold text-gray-900 block mb-1">Video Status</span>
                <span className="text-gray-500 text-[11px]">MP4, H.264 up to 30 seconds status chunks</span>
              </div>
              <div className="p-3 bg-gray-50 border border-gray-200 rounded-xl">
                <span className="font-bold text-gray-900 block mb-1">Voice / Audio</span>
                <span className="text-gray-500 text-[11px]">Voice note waveform status with player bar</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
