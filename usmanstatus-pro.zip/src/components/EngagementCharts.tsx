import React, { useState } from 'react';
import { 
  ResponsiveContainer, AreaChart, Area, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend
} from 'recharts';
import { 
  BarChart2, Clock, Calendar, TrendingUp, Flame, Users, 
  MessageSquare, Sparkles, Filter, Info, Eye
} from 'lucide-react';
import { SEVEN_DAYS_ENGAGEMENT, AGGREGATE_7_DAY_HOURLY, DAILY_7_DAY_TOTALS } from '../data/engagementData';

interface CustomTooltipProps {
  active?: boolean;
  payload?: any[];
  label?: string;
}

const CustomEngagementTooltip: React.FC<CustomTooltipProps> = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-gray-900/95 backdrop-blur-md text-white p-3.5 rounded-xl shadow-xl border border-gray-700 text-xs font-sans space-y-1.5 min-w-[190px]">
        <div className="flex items-center justify-between border-b border-gray-700 pb-1.5 font-bold text-gray-300">
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3 text-brand" /> {label} Hour
          </span>
          <span className="text-[10px] text-emerald-400 font-mono">Live Sync</span>
        </div>

        <div className="flex items-center justify-between text-gray-200">
          <span className="text-gray-400">Status Views:</span>
          <span className="font-extrabold text-emerald-400 text-sm">
            {data.views?.toLocaleString()} views
          </span>
        </div>

        <div className="flex items-center justify-between text-gray-200">
          <span className="text-gray-400">Total Group Reach:</span>
          <span className="font-semibold text-blue-300">
            {data.reach?.toLocaleString()} members
          </span>
        </div>

        <div className="flex items-center justify-between text-gray-200">
          <span className="text-gray-400">Direct Inquiries:</span>
          <span className="font-semibold text-purple-300">
            {data.replies} replies
          </span>
        </div>

        {data.peakStatusTitle && (
          <div className="mt-1.5 pt-1.5 border-t border-gray-700 text-[10px] text-amber-300">
            ⭐ Peak: {data.peakStatusTitle}
          </div>
        )}
      </div>
    );
  }
  return null;
};

export const EngagementCharts: React.FC = () => {
  const [selectedDayIndex, setSelectedDayIndex] = useState<number | 'avg'>('avg');
  const [chartType, setChartType] = useState<'area' | 'bar'>('area');

  const currentDataset = selectedDayIndex === 'avg' 
    ? AGGREGATE_7_DAY_HOURLY 
    : SEVEN_DAYS_ENGAGEMENT[selectedDayIndex]?.hourly || AGGREGATE_7_DAY_HOURLY;

  const currentDayInfo = selectedDayIndex === 'avg'
    ? { title: '7-Day Average Hourly Engagement', totalViews: 27070, peak: '20:00 (8:00 PM)' }
    : { 
        title: `${SEVEN_DAYS_ENGAGEMENT[selectedDayIndex].dayName} Hourly Engagement`,
        totalViews: SEVEN_DAYS_ENGAGEMENT[selectedDayIndex].totalViews,
        peak: SEVEN_DAYS_ENGAGEMENT[selectedDayIndex].peakHour 
      };

  return (
    <div className="space-y-6">
      
      {/* Chart Header & Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-gray-100">
        <div>
          <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
            <BarChart2 className="w-5 h-5 text-brand" />
            <span>WhatsApp Status Engagement (Views Per Hour - Last 7 Days)</span>
          </h3>
          <p className="text-xs text-gray-500 mt-0.5">
            24-hour viewing distribution and audience response analytics across all connected groups
          </p>
        </div>

        {/* Day Selector Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 lg:pb-0">
          <button
            onClick={() => setSelectedDayIndex('avg')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition ${
              selectedDayIndex === 'avg'
                ? 'bg-brand text-white shadow-xs'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            All 7 Days (Avg)
          </button>
          
          {SEVEN_DAYS_ENGAGEMENT.map((day, idx) => (
            <button
              key={day.date}
              onClick={() => setSelectedDayIndex(idx)}
              className={`px-2.5 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition ${
                selectedDayIndex === idx
                  ? 'bg-brand text-white font-bold shadow-xs'
                  : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
              }`}
            >
              {day.dayName.split(' ')[0]}
            </button>
          ))}
        </div>
      </div>

      {/* Highlights Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-gradient-to-br from-amber-50 to-orange-50/70 p-4 rounded-xl border border-amber-200/80 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
            <Flame className="w-5 h-5 fill-current text-amber-600" />
          </div>
          <div>
            <span className="text-[11px] text-amber-800 font-bold block">Prime Viewing Window</span>
            <div className="text-sm font-extrabold text-amber-950">18:00 - 21:00 (6 PM - 9 PM)</div>
            <span className="text-[10px] text-amber-700">Highest view-to-reply conversion</span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-emerald-50 to-teal-50/70 p-4 rounded-xl border border-emerald-200/80 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
            <TrendingUp className="w-5 h-5 text-emerald-600" />
          </div>
          <div>
            <span className="text-[11px] text-emerald-800 font-bold block">Selected Period Views</span>
            <div className="text-sm font-extrabold text-emerald-950">{currentDayInfo.totalViews.toLocaleString()} Views</div>
            <span className="text-[10px] text-emerald-700">Peak hour: {currentDayInfo.peak}</span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-50 to-brand-light/70 p-4 rounded-xl border border-brand/20 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-brand-light text-brand flex items-center justify-center shrink-0">
            <MessageSquare className="w-5 h-5 text-brand" />
          </div>
          <div>
            <span className="text-[11px] text-brand-dark font-bold block">Weekly Conversion Rate</span>
            <div className="text-sm font-extrabold text-brand-dark">9.4% DM Reply Rate</div>
            <span className="text-[10px] text-brand">340+ direct customer inquiries</span>
          </div>
        </div>
      </div>

      {/* Main Recharts Area / Bar Graph: Views Per Hour */}
      <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-gray-800">
              {currentDayInfo.title}
            </span>
            <span className="text-[10px] font-mono text-gray-400 bg-gray-100 px-2 py-0.5 rounded">
              24-Hour Timeline
            </span>
          </div>

          <div className="flex items-center gap-1 text-xs">
            <button
              onClick={() => setChartType('area')}
              className={`px-2.5 py-1 rounded text-xs font-semibold ${
                chartType === 'area' ? 'bg-brand/10 text-brand' : 'text-gray-500 hover:bg-gray-100'
              }`}
            >
              Smooth Area
            </button>
            <button
              onClick={() => setChartType('bar')}
              className={`px-2.5 py-1 rounded text-xs font-semibold ${
                chartType === 'bar' ? 'bg-brand/10 text-brand' : 'text-gray-500 hover:bg-gray-100'
              }`}
            >
              Hourly Bars
            </button>
          </div>
        </div>

        {/* The Recharts Graph Container */}
        <div className="w-full h-72 sm:h-80">
          <ResponsiveContainer width="100%" height="100%">
            {chartType === 'area' ? (
              <AreaChart data={currentDataset} margin={{ top: 10, right: 15, left: -10, bottom: 0 }}>
                <defs>
                  <linearGradient id="viewsGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#5a49ff" stopOpacity={0.45} />
                    <stop offset="95%" stopColor="#5a49ff" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="reachGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis 
                  dataKey="hour" 
                  tick={{ fontSize: 11, fill: '#64748b' }} 
                  axisLine={{ stroke: '#e2e8f0' }}
                  tickLine={false}
                />
                <YAxis 
                  tick={{ fontSize: 11, fill: '#64748b' }} 
                  axisLine={{ stroke: '#e2e8f0' }}
                  tickLine={false}
                />
                <Tooltip content={<CustomEngagementTooltip />} />
                <Legend 
                  verticalAlign="top" 
                  height={36} 
                  iconType="circle"
                  wrapperStyle={{ fontSize: '12px', fontWeight: 600 }}
                />
                <Area 
                  type="monotone" 
                  dataKey="views" 
                  name="Status Views" 
                  stroke="#5a49ff" 
                  strokeWidth={2.5} 
                  fillOpacity={1} 
                  fill="url(#viewsGradient)" 
                />
                <Area 
                  type="monotone" 
                  dataKey="reach" 
                  name="Potential Reach" 
                  stroke="#10b981" 
                  strokeWidth={1.5} 
                  strokeDasharray="4 4"
                  fillOpacity={1} 
                  fill="url(#reachGradient)" 
                />
              </AreaChart>
            ) : (
              <BarChart data={currentDataset} margin={{ top: 10, right: 15, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis 
                  dataKey="hour" 
                  tick={{ fontSize: 11, fill: '#64748b' }} 
                  axisLine={{ stroke: '#e2e8f0' }}
                  tickLine={false}
                />
                <YAxis 
                  tick={{ fontSize: 11, fill: '#64748b' }} 
                  axisLine={{ stroke: '#e2e8f0' }}
                  tickLine={false}
                />
                <Tooltip content={<CustomEngagementTooltip />} />
                <Legend 
                  verticalAlign="top" 
                  height={36} 
                  iconType="circle"
                  wrapperStyle={{ fontSize: '12px', fontWeight: 600 }}
                />
                <Bar 
                  dataKey="views" 
                  name="Status Views" 
                  fill="#5a49ff" 
                  radius={[4, 4, 0, 0]} 
                />
                <Bar 
                  dataKey="replies" 
                  name="DM Inquiries" 
                  fill="#10b981" 
                  radius={[4, 4, 0, 0]} 
                />
              </BarChart>
            )}
          </ResponsiveContainer>
        </div>
      </div>

      {/* 7-Day Cumulative Totals Trend Chart */}
      <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <span className="text-xs font-bold text-gray-800 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-brand" />
            <span>7-Day Daily Aggregate Trend (Aug 22 - Aug 28)</span>
          </span>
          <span className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5" /> +28.4% Week-over-Week Growth
          </span>
        </div>

        <div className="w-full h-56">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={DAILY_7_DAY_TOTALS} margin={{ top: 10, right: 15, left: -10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis 
                dataKey="day" 
                tick={{ fontSize: 11, fill: '#64748b' }} 
                axisLine={{ stroke: '#e2e8f0' }}
                tickLine={false}
              />
              <YAxis 
                tick={{ fontSize: 11, fill: '#64748b' }} 
                axisLine={{ stroke: '#e2e8f0' }}
                tickLine={false}
              />
              <Tooltip 
                formatter={(value: any, name: any) => [`${Number(value).toLocaleString()}`, name]}
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#fff', borderRadius: '12px', fontSize: '12px' }}
              />
              <Legend verticalAlign="top" height={32} wrapperStyle={{ fontSize: '12px' }} />
              <Bar dataKey="views" name="Daily Total Views" fill="#7356bf" radius={[4, 4, 0, 0]} />
              <Bar dataKey="reach" name="Group Reach" fill="#075e54" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

    </div>
  );
};
