import React from 'react';
import { X, Layers, Radio, Palette, BarChart2, ShieldCheck, Zap, Bot, ArrowRight } from 'lucide-react';

interface FeaturesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenDashboard: () => void;
}

export const FeaturesModal: React.FC<FeaturesModalProps> = ({ isOpen, onClose, onOpenDashboard }) => {
  if (!isOpen) return null;

  const features = [
    {
      title: 'Real Group Status (Not a Chat Message)',
      desc: 'Dispatches actual WhatsApp group status stories visible in the Updates tab with full media fidelity, link chips, and color backgrounds.',
      icon: Layers,
      highlight: 'Baileys Multi-Device Protocol',
    },
    {
      title: 'Broadcast to All Groups with Exclusions',
      desc: 'Send once to reach 10, 50, or 200 groups simultaneously. Filter out private groups or specific JIDs in a single click.',
      icon: Radio,
      highlight: 'Targeting Engine',
    },
    {
      title: '18 Authentic Color Backgrounds',
      desc: 'Every native WhatsApp status gradient and solid shade pre-configured, plus custom hex codes and typographic pairings.',
      icon: Palette,
      highlight: 'Live Visual Studio',
    },
    {
      title: 'Dashboard & Analytics with DM Reports',
      desc: 'Get a clean daily summary sent directly to your WhatsApp DM with view rates, active reach, and reply counts.',
      icon: BarChart2,
      highlight: 'Automated 8:00 AM Cron',
    },
    {
      title: 'Token-Gated Multi-Tenant Architecture',
      desc: 'Admins can issue time-bounded or quota-limited access tokens for clients, employees, and agency team members.',
      icon: ShieldCheck,
      highlight: 'Single-Use & Multi-Use Keys',
    },
    {
      title: 'Zero WhatsApp Account Bans / Safe Queue',
      desc: 'Built-in pacing, jitter delays, and socket throttling protect your session from aggressive rate limits.',
      icon: Zap,
      highlight: 'Safe Queue Engine',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-2xl max-w-3xl w-full p-6 md:p-8 shadow-2xl border border-gray-100 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-4 border-b border-gray-100 mb-6">
          <div>
            <span className="text-xs font-bold text-brand uppercase tracking-wider">Features Overview</span>
            <h3 className="text-2xl font-bold text-gray-900">Engineered for WhatsApp Power Users</h3>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-gray-700 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {features.map((feat, idx) => {
            const Icon = feat.icon;
            return (
              <div key={idx} className="p-4 rounded-xl bg-gray-50 border border-gray-100 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="w-9 h-9 bg-brand-light text-brand rounded-lg flex items-center justify-center">
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold bg-white text-gray-600 px-2 py-0.5 rounded border border-gray-200">
                      {feat.highlight}
                    </span>
                  </div>
                  <h4 className="font-bold text-gray-900 text-sm mb-1">{feat.title}</h4>
                  <p className="text-xs text-gray-500 leading-relaxed">{feat.desc}</p>
                </div>
              </div>
            );
          })}
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-gray-100">
          <span className="text-xs text-gray-500">Explore all features live inside the dashboard.</span>
          <button
            onClick={() => {
              onClose();
              onOpenDashboard();
            }}
            className="bg-brand hover:bg-brand-dark text-white px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm"
          >
            Open Live Dashboard <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
