import React, { useState } from 'react';
import { 
  BarChart2, TrendingUp, Users, Eye, Send, CheckCircle2, 
  MessageSquare, Copy, Check, Calendar, Phone, Sparkles, Smartphone
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { WhatsAppStatus, DMReport } from '../types';
import { EngagementCharts } from './EngagementCharts';

interface AnalyticsReportsProps {
  statuses: WhatsAppStatus[];
  dmReports: DMReport[];
  recipientPhone: string;
  onSendTestDmReport: (phone: string) => void;
}

export const AnalyticsReports: React.FC<AnalyticsReportsProps> = ({
  statuses,
  dmReports,
  recipientPhone,
  onSendTestDmReport,
}) => {
  const [selectedReport, setSelectedReport] = useState<DMReport>(dmReports[0] || null);
  const [customPhone, setCustomPhone] = useState(recipientPhone);
  const [isSendingDm, setIsSendingDm] = useState(false);
  const [copiedReport, setCopiedReport] = useState(false);
  const [dmSuccessToast, setDmSuccessToast] = useState<string | null>(null);

  const totalViews = statuses.reduce((acc, s) => acc + (s.viewCount || 0), 0);
  const totalDelivered = statuses.reduce((acc, s) => acc + (s.totalDelivered || 0), 0);

  const handleCopyReport = () => {
    if (!selectedReport) return;
    navigator.clipboard.writeText(selectedReport.rawReportText);
    setCopiedReport(true);
    setTimeout(() => setCopiedReport(false), 2000);
  };

  const handleTriggerDm = () => {
    setIsSendingDm(true);
    setTimeout(() => {
      setIsSendingDm(false);
      onSendTestDmReport(customPhone);
      confetti({
        particleCount: 60,
        spread: 60,
        origin: { y: 0.7 }
      });
      setDmSuccessToast(`Daily Status Report successfully delivered to WhatsApp DM (${customPhone})!`);
      setTimeout(() => setDmSuccessToast(null), 5000);
    }, 1200);
  };

  return (
    <div className="space-y-8">
      {/* Top Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="bg-white rounded-2xl p-5 shadow-[0_4px_25px_-5px_rgba(0,0,0,0.05)] border border-gray-100 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-brand-light text-brand flex items-center justify-center shrink-0">
            <Send className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-gray-500 font-medium">Broadcasted Statuses</span>
            <div className="text-2xl font-extrabold text-gray-900">{statuses.length}</div>
            <span className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
              <TrendingUp className="w-3 h-3" /> 100% Baileys delivery rate
            </span>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-5 shadow-[0_4px_25px_-5px_rgba(0,0,0,0.05)] border border-gray-100 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <Eye className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-gray-500 font-medium">Total Status Views</span>
            <div className="text-2xl font-extrabold text-gray-900">{totalViews.toLocaleString()}</div>
            <span className="text-[11px] text-emerald-600 font-semibold">
              Across all linked group JIDs
            </span>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-5 shadow-[0_4px_25px_-5px_rgba(0,0,0,0.05)] border border-gray-100 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-gray-500 font-medium">Total Transmissions</span>
            <div className="text-2xl font-extrabold text-gray-900">{totalDelivered}</div>
            <span className="text-[11px] text-gray-500">
              Zero group chat spam
            </span>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-5 shadow-[0_4px_25px_-5px_rgba(0,0,0,0.05)] border border-gray-100 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0">
            <MessageSquare className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-gray-500 font-medium">Daily DM Reports</span>
            <div className="text-2xl font-extrabold text-gray-900">{dmReports.length} Sent</div>
            <span className="text-[11px] text-emerald-600 font-semibold">
              Delivered daily at 08:00 AM
            </span>
          </div>
        </div>
      </div>

      {/* RECHARTS 7-DAY HOURLY ENGAGEMENT GRAPH */}
      <div className="bg-white rounded-2xl p-6 md:p-8 shadow-[0_4px_25px_-5px_rgba(0,0,0,0.05)] border border-gray-100">
        <EngagementCharts />
      </div>

      {/* DM Reports & Live Bot Trigger Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left: DM Report Visualizer (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-6 md:p-8 shadow-[0_4px_25px_-5px_rgba(0,0,0,0.05)] border border-gray-100">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-gray-100 mb-5">
            <div>
              <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-brand" />
                <span>Daily DM Report Generator</span>
              </h3>
              <p className="text-xs text-gray-500">
                Automated performance summary sent straight to your personal WhatsApp chat
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopyReport}
                className="px-3 py-1.5 rounded-lg bg-gray-50 hover:bg-gray-100 text-gray-700 border border-gray-200 text-xs font-semibold flex items-center gap-1.5 transition"
              >
                {copiedReport ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedReport ? 'Copied!' : 'Copy Text'}</span>
              </button>
            </div>
          </div>

          {/* DM Report Preview Box formatted like WhatsApp */}
          <div className="bg-[#0c1317] text-[#e9edef] rounded-2xl p-5 font-mono text-xs leading-relaxed relative border border-gray-800 shadow-inner mb-6">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-white/10 text-[11px] text-gray-400 font-sans">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block"></span>
                <span className="font-bold text-white">UsmanStatus Pro Bot</span>
              </div>
              <span>{selectedReport?.date} · {selectedReport?.time}</span>
            </div>

            <pre className="whitespace-pre-wrap font-sans text-xs text-gray-200">
              {selectedReport?.rawReportText || 'Generating daily report...'}
            </pre>
          </div>

          {/* Test DM Trigger Form */}
          <div className="bg-gray-50 p-4 rounded-xl border border-gray-200/80">
            <span className="text-xs font-bold text-gray-800 block mb-2">
              Send Live Test Report to WhatsApp Number
            </span>
            <div className="flex flex-col sm:flex-row items-stretch gap-2.5">
              <div className="relative flex-1">
                <Phone className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  value={customPhone}
                  onChange={(e) => setCustomPhone(e.target.value)}
                  placeholder="+1 (555) 019-2834"
                  className="w-full pl-9 pr-3 py-2 bg-white rounded-lg border border-gray-200 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-brand/40"
                />
              </div>

              <button
                type="button"
                disabled={isSendingDm}
                onClick={handleTriggerDm}
                className="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-2 transition shadow-sm shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isSendingDm ? 'Transmitting to WhatsApp...' : 'Send to my WhatsApp DM'}</span>
              </button>
            </div>
            <p className="text-[11px] text-gray-500 mt-2">
              Reports include hourly view metrics, group deliverability, and top-converting group rankings.
            </p>
          </div>

          {dmSuccessToast && (
            <div className="mt-4 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2 animate-fadeIn">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{dmSuccessToast}</span>
            </div>
          )}
        </div>

        {/* Right: Status Broadcast History Log (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-2xl p-6 md:p-8 shadow-[0_4px_25px_-5px_rgba(0,0,0,0.05)] border border-gray-100">
          <div className="pb-4 border-b border-gray-100 mb-4 flex items-center justify-between">
            <h3 className="text-base font-bold text-gray-900">Recent Status Broadcasts</h3>
            <span className="text-xs font-bold text-brand bg-brand-light px-2 py-0.5 rounded-full">
              {statuses.length} Recorded
            </span>
          </div>

          <div className="space-y-3 overflow-y-auto max-h-[480px] pr-1">
            {statuses.map(st => (
              <div 
                key={st.id}
                className="p-3.5 rounded-xl border border-gray-200/80 hover:border-brand/40 bg-gray-50/50 hover:bg-white transition flex flex-col gap-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span 
                      className="w-3 h-3 rounded-full shrink-0 shadow-xs" 
                      style={{ backgroundColor: st.backgroundColor }}
                    ></span>
                    <span className="text-[11px] font-bold uppercase text-gray-700 bg-gray-100 px-2 py-0.5 rounded">
                      {st.type}
                    </span>
                    <span className="text-[11px] text-gray-400">{st.createdAt}</span>
                  </div>

                  <div className="flex items-center gap-1 text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    <Eye className="w-3 h-3" />
                    <span>{st.viewCount?.toLocaleString()} views</span>
                  </div>
                </div>

                <p className="text-xs text-gray-800 line-clamp-2 leading-relaxed">
                  {st.content || '(Media Status)'}
                </p>

                <div className="flex items-center justify-between text-[11px] text-gray-500 pt-1 border-t border-gray-100">
                  <span>Targeted {st.totalDelivered} groups</span>
                  {st.dmReportSent && (
                    <span className="text-brand font-semibold flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-500" /> DM Reported
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
