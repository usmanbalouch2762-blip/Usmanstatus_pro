import React, { useState } from 'react';
import { 
  Hexagon, LayoutGrid, Layers, Radio, Palette, BarChart2, 
  ShieldAlert, ShieldCheck, ArrowRight, CheckCircle2, KeyRound, Sparkles, HelpCircle,
  Cloud, LogIn, LogOut
} from 'lucide-react';
import { User } from 'firebase/auth';
import confetti from 'canvas-confetti';

interface LandingPageProps {
  user: User | null;
  firestoreConnected: boolean;
  onSignInWithGoogle: () => Promise<void>;
  onSignOut: () => Promise<void>;
  onOpenDashboard: () => void;
  onRedeemToken: (token: string) => boolean;
  onOpenHowItWorks: () => void;
  onOpenPricing: () => void;
  onOpenDocs: () => void;
  onOpenSupport: () => void;
  onOpenFeatures: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  user,
  firestoreConnected,
  onSignInWithGoogle,
  onSignOut,
  onOpenDashboard,
  onRedeemToken,
  onOpenHowItWorks,
  onOpenPricing,
  onOpenDocs,
  onOpenSupport,
  onOpenFeatures,
}) => {
  const [tokenInput, setTokenInput] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tokenInput.trim()) {
      setErrorMessage('Please enter your access token.');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      const success = onRedeemToken(tokenInput.trim());
      if (success) {
        confetti({
          particleCount: 70,
          spread: 70,
          origin: { y: 0.6 }
        });
      } else {
        setErrorMessage('Invalid or expired token. Try preset demo token below.');
      }
    }, 600);
  };

  const handleUsePreset = (code: string) => {
    setTokenInput(code);
    setErrorMessage(null);
  };

  return (
    <div className="bg-[#fbfcff] font-sans text-gray-900 antialiased relative overflow-x-hidden min-h-screen flex flex-col justify-between">
      
      {/* Background Ambient Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[900px] h-[500px] bg-brand-light rounded-full blur-[120px] -z-10 opacity-80 pointer-events-none"></div>

      <div>
        {/* Navigation */}
        <nav className="max-w-7xl mx-auto px-6 py-6 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <div className="w-8 h-8 rounded-lg bg-brand flex items-center justify-center text-white shadow-xs">
              <Hexagon className="w-5 h-5 fill-current" />
            </div>
            <span className="font-bold text-xl tracking-tight text-gray-900">UsmanStatus Pro</span>
          </div>
          
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-gray-600">
            <button 
              onClick={onOpenFeatures} 
              className="text-gray-900 hover:text-brand transition-colors cursor-pointer"
            >
              Features
            </button>
            <button 
              onClick={onOpenHowItWorks} 
              className="hover:text-brand transition-colors cursor-pointer"
            >
              How It Works
            </button>
            <button 
              onClick={onOpenPricing} 
              className="hover:text-brand transition-colors cursor-pointer"
            >
              Pricing
            </button>
            <button 
              onClick={onOpenDocs} 
              className="hover:text-brand transition-colors cursor-pointer"
            >
              Docs
            </button>
            <button 
              onClick={onOpenSupport} 
              className="hover:text-brand transition-colors cursor-pointer"
            >
              Support
            </button>
          </div>

          <div className="flex items-center gap-3">
            {/* Google Sign In or User Badge */}
            {user ? (
              <div className="flex items-center gap-2 bg-white border border-gray-200 pl-2 pr-3 py-1.5 rounded-full text-xs text-gray-700 shadow-xs">
                {user.photoURL ? (
                  <img src={user.photoURL} alt={user.displayName || 'User'} className="w-5 h-5 rounded-full" referrerPolicy="no-referrer" />
                ) : (
                  <div className="w-5 h-5 rounded-full bg-brand text-white text-[10px] flex items-center justify-center font-bold">
                    {(user.displayName || 'U')[0]}
                  </div>
                )}
                <span className="font-medium max-w-[100px] truncate hidden sm:inline">{user.displayName || user.email}</span>
                <button
                  onClick={onSignOut}
                  title="Sign out"
                  className="text-gray-400 hover:text-rose-600 transition ml-1"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button 
                onClick={onSignInWithGoogle}
                className="hidden sm:flex items-center gap-1.5 bg-white hover:bg-gray-50 border border-gray-200 text-gray-700 px-3.5 py-2 rounded-lg text-xs font-semibold shadow-xs transition"
              >
                <LogIn className="w-3.5 h-3.5 text-brand" />
                <span>Google Sign-In</span>
              </button>
            )}

            <button 
              onClick={onOpenDashboard}
              className="bg-brand hover:bg-brand-dark text-white px-5 py-2.5 rounded-lg flex items-center gap-2 text-sm font-semibold transition-colors shadow-sm cursor-pointer active:scale-95"
            >
              <LayoutGrid className="w-4 h-4" />
              Dashboard
            </button>
          </div>
        </nav>

        {/* Hero Section */}
        <section className="text-center pt-20 md:pt-24 pb-16 md:pb-20 px-4 max-w-4xl mx-auto">
          <div className="inline-flex items-center justify-center px-5 py-1.5 rounded-full bg-white text-xs font-semibold text-gray-600 shadow-[0_2px_10px_-4px_rgba(0,0,0,0.1)] border border-gray-100 mb-8">
            <span className="w-2 h-2 rounded-full border-2 border-brand mr-2 animate-pulse"></span>
            Cloud Firestore Connected &nbsp;·&nbsp; Token-Gated &nbsp;·&nbsp; Multi-Device
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold tracking-tight text-gray-900 mb-6 leading-[1.15]">
            Manage WhatsApp<br />
            Group Statuses <span className="text-brand">Like a Pro</span>
          </h1>
          
          <p className="text-lg text-gray-500 mb-10 max-w-2xl mx-auto leading-relaxed">
            Post text, image, video, and audio group statuses to single groups, 
            specific JIDs, or all groups — with daily reports sent straight to your DM and real-time cloud persistence.
          </p>

          {/* Quick Action Button */}
          <div className="flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={() => {
                const el = document.getElementById('token-section');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="bg-brand hover:bg-brand-dark text-white px-7 py-3.5 rounded-xl font-bold text-sm flex items-center gap-2 shadow-md hover:shadow-lg transition active:scale-95"
            >
              <KeyRound className="w-4 h-4" />
              Enter Access Token
            </button>

            <button
              onClick={onOpenDashboard}
              className="bg-white hover:bg-gray-50 text-gray-800 border border-gray-200 px-7 py-3.5 rounded-xl font-bold text-sm flex items-center gap-2 shadow-xs transition"
            >
              <LayoutGrid className="w-4 h-4 text-brand" />
              Open Live Dashboard
            </button>
          </div>
        </section>

        {/* Features Grid */}
        <section className="max-w-7xl mx-auto px-6 pb-24">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            
            {/* Card 1 */}
            <div 
              onClick={onOpenFeatures}
              className="bg-white rounded-[1.25rem] p-8 shadow-[0_8px_30px_-12px_rgba(0,0,0,0.06)] border border-gray-100/50 hover:-translate-y-1 transition-transform duration-300 flex flex-col h-full cursor-pointer group"
            >
              <div className="w-12 h-12 bg-brand-light rounded-xl flex items-center justify-center text-brand mb-6 group-hover:scale-110 transition-transform">
                <Layers className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-gray-900 mb-3 text-base">Real Group Status</h3>
              <p className="text-gray-500 text-sm leading-relaxed mb-8 flex-grow">
                Post as actual WhatsApp Group Status (not a regular message) with full media, color, and caption support.
              </p>
              <div className="w-8 h-[3px] bg-brand/30 rounded-full group-hover:w-16 group-hover:bg-brand transition-all"></div>
            </div>

            {/* Card 2 */}
            <div 
              onClick={onOpenFeatures}
              className="bg-white rounded-[1.25rem] p-8 shadow-[0_8px_30px_-12px_rgba(0,0,0,0.06)] border border-gray-100/50 hover:-translate-y-1 transition-transform duration-300 flex flex-col h-full cursor-pointer group"
            >
              <div className="w-12 h-12 bg-brand-light rounded-xl flex items-center justify-center text-brand mb-6 group-hover:scale-110 transition-transform">
                <Radio className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-gray-900 mb-3 text-base">Broadcast to All Groups</h3>
              <p className="text-gray-500 text-sm leading-relaxed mb-8 flex-grow">
                Send to every group you're in with one command. Exclude specific groups by JID. Supports media too.
              </p>
              <div className="w-8 h-[3px] bg-brand/30 rounded-full group-hover:w-16 group-hover:bg-brand transition-all"></div>
            </div>

            {/* Card 3 */}
            <div 
              onClick={onOpenFeatures}
              className="bg-white rounded-[1.25rem] p-8 shadow-[0_8px_30px_-12px_rgba(0,0,0,0.06)] border border-gray-100/50 hover:-translate-y-1 transition-transform duration-300 flex flex-col h-full cursor-pointer group"
            >
              <div className="w-12 h-12 bg-brand-light rounded-xl flex items-center justify-center text-brand mb-6 group-hover:scale-110 transition-transform">
                <Palette className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-gray-900 mb-3 text-base">18 Color Backgrounds</h3>
              <p className="text-gray-500 text-sm leading-relaxed mb-8 flex-grow">
                Choose from named colors or enter any hex code for text status backgrounds. Dashboard lets you pick visually.
              </p>
              <div className="w-8 h-[3px] bg-brand/30 rounded-full group-hover:w-16 group-hover:bg-brand transition-all"></div>
            </div>

            {/* Card 4 */}
            <div 
              onClick={onOpenFeatures}
              className="bg-white rounded-[1.25rem] p-8 shadow-[0_8px_30px_-12px_rgba(0,0,0,0.06)] border border-gray-100/50 hover:-translate-y-1 transition-transform duration-300 flex flex-col h-full cursor-pointer group"
            >
              <div className="w-12 h-12 bg-brand-light rounded-xl flex items-center justify-center text-brand mb-6 group-hover:scale-110 transition-transform">
                <BarChart2 className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-gray-900 mb-3 text-base">Dashboard & Analytics</h3>
              <p className="text-gray-500 text-sm leading-relaxed mb-8 flex-grow">
                Web dashboard for posting, group management, analytics, and session controls. Daily reports to your DM.
              </p>
              <div className="w-8 h-[3px] bg-brand/30 rounded-full group-hover:w-16 group-hover:bg-brand transition-all"></div>
            </div>

          </div>
        </section>

        {/* Token Entry Section */}
        <section id="token-section" className="max-w-5xl mx-auto px-6 pb-24 scroll-mt-10">
          <div className="bg-white rounded-[2rem] shadow-[0_10px_40px_-10px_rgba(0,0,0,0.08)] flex flex-col md:flex-row overflow-hidden border border-gray-100/60">
            
            {/* Left Side: Abstract 3D Glass Graphic */}
            <div className="md:w-5/12 bg-gradient-to-br from-[#e0d6ff] to-[#f4f0ff] p-10 flex items-center justify-center min-h-[350px] relative overflow-hidden border-r border-gray-50">
              {/* Glowing orb */}
              <div className="absolute w-48 h-48 bg-white/60 rounded-full blur-2xl opacity-70 pointer-events-none"></div>
              
              {/* Glass panel back */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 -ml-6 -mt-4 w-40 h-52 bg-white/30 backdrop-blur-md rounded-2xl border border-white/50 shadow-sm transform -rotate-6">
                <div className="p-5 space-y-3 opacity-30 mt-4">
                  <div className="h-2.5 w-3/4 bg-brand rounded"></div>
                  <div className="h-2.5 w-1/2 bg-brand rounded"></div>
                  <div className="h-2.5 w-full bg-brand rounded"></div>
                </div>
              </div>
              
              {/* Glass panel front */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 ml-4 mt-6 w-44 h-48 bg-white/40 backdrop-blur-xl rounded-2xl border border-white/80 shadow-lg flex items-center justify-center">
                <div className="w-16 h-20 bg-brand/10 border-2 border-brand/20 rounded-xl flex items-center justify-center shadow-inner">
                  <ShieldAlert className="w-7 h-7 text-brand" />
                </div>
              </div>
            </div>

            {/* Right Side: Form */}
            <div className="md:w-7/12 p-10 md:p-14 lg:p-16 flex flex-col justify-center">
              <h2 className="text-3xl font-bold text-gray-900 mb-3 tracking-tight">Enter Access Token</h2>
              <p className="text-gray-500 mb-6 text-sm leading-relaxed">
                You need a valid access token from your admin to connect your WhatsApp account.
              </p>
              
              <form onSubmit={handleFormSubmit}>
                <label className="block text-sm font-bold text-gray-900 mb-2">Access Token</label>
                <div className="relative mb-2">
                  <input 
                    type="text" 
                    value={tokenInput}
                    onChange={(e) => {
                      setTokenInput(e.target.value);
                      setErrorMessage(null);
                    }}
                    placeholder="Paste your access token here" 
                    className="w-full px-4 py-3.5 rounded-lg border border-gray-200 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-brand/40 focus:border-brand transition"
                  />
                </div>

                {errorMessage && (
                  <p className="text-xs text-rose-600 mb-3 font-semibold flex items-center gap-1 animate-fadeIn">
                    <ShieldAlert className="w-3.5 h-3.5" />
                    {errorMessage}
                  </p>
                )}

                {/* Quick Presets */}
                <div className="mb-6 p-3 bg-gray-50 rounded-xl border border-gray-100">
                  <span className="text-[11px] font-bold text-gray-500 block mb-1.5 flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-brand" /> Click to test instant demo tokens:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    <button
                      type="button"
                      onClick={() => handleUsePreset('USMAN-PRO-DEMO-2026')}
                      className="text-[11px] font-mono bg-white hover:bg-brand-light hover:text-brand px-2.5 py-1 rounded border border-gray-200 text-gray-700 transition"
                    >
                      USMAN-PRO-DEMO-2026 (User)
                    </button>
                    <button
                      type="button"
                      onClick={() => handleUsePreset('USMAN-VIP-9941')}
                      className="text-[11px] font-mono bg-white hover:bg-brand-light hover:text-brand px-2.5 py-1 rounded border border-gray-200 text-gray-700 transition"
                    >
                      USMAN-VIP-9941 (VIP)
                    </button>
                    <button
                      type="button"
                      onClick={() => handleUsePreset('ADMIN-SUPER-KEY')}
                      className="text-[11px] font-mono bg-white hover:bg-brand-light hover:text-brand px-2.5 py-1 rounded border border-gray-200 text-gray-700 transition"
                    >
                      ADMIN-SUPER-KEY (Admin)
                    </button>
                  </div>
                </div>

                <p className="text-xs text-gray-400 mb-6 leading-relaxed">
                  Token is provided by your administrator.<br />
                  Each token can only be used once.
                </p>
                
                <button 
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-brand hover:bg-brand-dark text-white font-medium py-3.5 rounded-lg flex items-center justify-center gap-2 transition-colors shadow-sm cursor-pointer disabled:opacity-50"
                >
                  <span>{isSubmitting ? 'Verifying Token...' : 'Redeem Token'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            </div>
          </div>
        </section>
      </div>

      {/* Footer */}
      <footer className="border-t border-gray-100 bg-white pt-16 pb-8 px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-10 lg:gap-6 mb-16">
          
          {/* Brand Info */}
          <div className="lg:col-span-2 pr-4">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-7 h-7 rounded-md bg-brand flex items-center justify-center text-white">
                <Hexagon className="w-4 h-4 fill-current" />
              </div>
              <span className="font-bold text-lg tracking-tight text-gray-900">UsmanStatus Pro</span>
            </div>
            <p className="text-sm text-gray-500 leading-relaxed">
              Professional WhatsApp Group<br />Status Manager
            </p>
          </div>

          {/* Links */}
          <div className="lg:col-span-1">
            <h4 className="font-bold text-gray-900 mb-4 text-sm">Product</h4>
            <ul className="space-y-3 text-sm text-gray-500 font-medium">
              <li><button onClick={onOpenFeatures} className="hover:text-brand transition-colors">Features</button></li>
              <li><button onClick={onOpenHowItWorks} className="hover:text-brand transition-colors">How It Works</button></li>
              <li><button onClick={onOpenPricing} className="hover:text-brand transition-colors">Pricing</button></li>
              <li><button onClick={onOpenDocs} className="hover:text-brand transition-colors">Docs</button></li>
            </ul>
          </div>

          <div className="lg:col-span-1">
            <h4 className="font-bold text-gray-900 mb-4 text-sm">Company</h4>
            <ul className="space-y-3 text-sm text-gray-500 font-medium">
              <li><button onClick={onOpenFeatures} className="hover:text-brand transition-colors">About Us</button></li>
              <li><button onClick={onOpenSupport} className="hover:text-brand transition-colors">Contact</button></li>
              <li><button onClick={onOpenDocs} className="hover:text-brand transition-colors">Privacy Policy</button></li>
              <li><button onClick={onOpenDocs} className="hover:text-brand transition-colors">Terms of Service</button></li>
            </ul>
          </div>

          <div className="lg:col-span-1">
            <h4 className="font-bold text-gray-900 mb-4 text-sm">Support</h4>
            <ul className="space-y-3 text-sm text-gray-500 font-medium">
              <li><button onClick={onOpenDocs} className="hover:text-brand transition-colors">Documentation</button></li>
              <li><button onClick={onOpenHowItWorks} className="hover:text-brand transition-colors">Guides</button></li>
              <li><button onClick={onOpenSupport} className="hover:text-brand transition-colors">Contact Support</button></li>
            </ul>
          </div>

          {/* Secure Badge */}
          <div className="lg:col-span-1 lg:-ml-6 flex items-start">
            <div className="bg-[#fbfcff] border border-gray-100 rounded-xl p-4 flex gap-3 shadow-sm max-w-xs">
              <ShieldCheck className="text-brand w-5 h-5 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-bold text-gray-900 leading-none mb-1.5">Cloud Firestore Secured</h4>
                <p className="text-xs text-gray-500 leading-tight">Your data is synced & protected by Zero-Trust ABAC rules.</p>
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto text-center text-xs font-medium text-gray-400">
          &copy; 2026 UsmanStatus Pro. All rights reserved.
        </div>
      </footer>
    </div>
  );
};
