import React, { useState } from 'react';
import { 
  Type, Image as ImageIcon, Video, Mic, Palette, Check, 
  Send, Sparkles, AlertCircle, Clock, Upload, Trash2, 
  Radio, CheckSquare, Square, ChevronDown, CheckCircle2, Shield, Calendar, Repeat
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { WHATSAPP_18_COLORS } from '../data/whatsappColors';
import { WhatsAppGroup, WhatsAppStatus, StatusMediaType } from '../types';
import { StatusPhonePreview } from './StatusPhonePreview';
import { ScheduledQueueManager } from './ScheduledQueueManager';

interface StatusComposerProps {
  groups: WhatsAppGroup[];
  scheduledStatuses?: WhatsAppStatus[];
  onPostStatus: (status: Omit<WhatsAppStatus, 'id' | 'createdAt' | 'viewCount' | 'totalDelivered' | 'totalTargeted'>) => void;
  onDispatchScheduledNow?: (statusId: string) => void;
  onCancelScheduled?: (statusId: string) => void;
  onRescheduleStatus?: (statusId: string, newTime: string) => void;
  statusQuotasRemaining: number;
}

export const StatusComposer: React.FC<StatusComposerProps> = ({
  groups,
  scheduledStatuses = [],
  onPostStatus,
  onDispatchScheduledNow,
  onCancelScheduled,
  onRescheduleStatus,
  statusQuotasRemaining,
}) => {
  const [statusType, setStatusType] = useState<StatusMediaType>('text');
  const [content, setContent] = useState('🔥 FLASH SALE: 40% OFF all VIP Status Manager sub-accounts! DM @Usman to claim your instant token.');
  const [backgroundColor, setBackgroundColor] = useState('#7356bf');
  const [customHex, setCustomHex] = useState('#7356bf');
  const [fontStyle, setFontStyle] = useState<'sans' | 'serif' | 'mono' | 'bold' | 'handwriting'>('bold');
  const [mediaUrl, setMediaUrl] = useState<string>('https://images.unsplash.com/photo-1557804506-669a67965ba0?w=800&q=80');
  const [mediaName, setMediaName] = useState<string>('vip-announcement-card.jpg');
  const [audioDuration, setAudioDuration] = useState('0:35');
  
  // Target setup
  const [targetMode, setTargetMode] = useState<'all' | 'specific'>('all');
  const [selectedJids, setSelectedJids] = useState<string[]>(
    groups.filter(g => !g.isExcluded).map(g => g.jid)
  );

  // Scheduling State
  const [isScheduled, setIsScheduled] = useState(false);
  const [scheduledDate, setScheduledDate] = useState('');
  const [scheduledTime, setScheduledTime] = useState('20:00');
  const [recurrence, setRecurrence] = useState<'once' | 'daily' | 'weekly'>('once');
  const [sendDmReport, setSendDmReport] = useState(true);

  // UI State
  const [isSending, setIsSending] = useState(false);
  const [sendProgress, setSendProgress] = useState(0);
  const [sendingGroupIndex, setSendingGroupIndex] = useState(0);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const activeTargetGroups = targetMode === 'all' 
    ? groups.filter(g => !g.isExcluded)
    : groups.filter(g => selectedJids.includes(g.jid));

  const excludedGroupsCount = groups.filter(g => g.isExcluded).length;

  const fontOptions: ('sans' | 'serif' | 'mono' | 'bold' | 'handwriting')[] = [
    'sans', 'bold', 'serif', 'mono', 'handwriting'
  ];

  const handleCycleFont = () => {
    const currentIndex = fontOptions.indexOf(fontStyle);
    const nextIndex = (currentIndex + 1) % fontOptions.length;
    setFontStyle(fontOptions[nextIndex]);
  };

  const handleColorSelect = (hex: string) => {
    setBackgroundColor(hex);
    setCustomHex(hex);
  };

  const handleCustomHexChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setCustomHex(val);
    if (/^#[0-9A-F]{6}$/i.test(val)) {
      setBackgroundColor(val);
    }
  };

  const handleToggleJid = (jid: string) => {
    if (selectedJids.includes(jid)) {
      setSelectedJids(selectedJids.filter(j => j !== jid));
    } else {
      setSelectedJids([...selectedJids, jid]);
    }
  };

  const handleSelectAllJids = () => {
    setSelectedJids(groups.filter(g => !g.isExcluded).map(g => g.jid));
  };

  const handleDeselectAllJids = () => {
    setSelectedJids([]);
  };

  const handlePresetMedia = (url: string, name: string, type: StatusMediaType) => {
    setStatusType(type);
    setMediaUrl(url);
    setMediaName(name);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const fakeUrl = URL.createObjectURL(file);
      setMediaUrl(fakeUrl);
      setMediaName(file.name);
      if (file.type.startsWith('image/')) setStatusType('image');
      else if (file.type.startsWith('video/')) setStatusType('video');
      else if (file.type.startsWith('audio/')) setStatusType('audio');
    }
  };

  // Helper for quick schedule buttons
  const setQuickSchedule = (type: 'plus1h' | 'todayPrime' | 'tomorrowMorning' | 'tomorrowPrime') => {
    setIsScheduled(true);
    const now = new Date();

    if (type === 'plus1h') {
      now.setHours(now.getHours() + 1);
      setScheduledDate(now.toISOString().split('T')[0]);
      setScheduledTime(`${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`);
    } else if (type === 'todayPrime') {
      setScheduledDate(now.toISOString().split('T')[0]);
      setScheduledTime('20:30');
    } else if (type === 'tomorrowMorning') {
      now.setDate(now.getDate() + 1);
      setScheduledDate(now.toISOString().split('T')[0]);
      setScheduledTime('09:00');
    } else if (type === 'tomorrowPrime') {
      now.setDate(now.getDate() + 1);
      setScheduledDate(now.toISOString().split('T')[0]);
      setScheduledTime('20:00');
    }
  };

  const handleBroadcast = () => {
    if (!content.trim() && statusType === 'text') {
      alert('Please enter a status message text.');
      return;
    }
    if (activeTargetGroups.length === 0) {
      alert('Please select at least one active target group.');
      return;
    }

    const scheduledIso = isScheduled && scheduledDate && scheduledTime 
      ? `${scheduledDate}T${scheduledTime}:00` 
      : isScheduled 
        ? new Date(Date.now() + 3600000).toISOString() 
        : undefined;

    if (isScheduled) {
      // Direct schedule
      onPostStatus({
        type: statusType,
        content,
        mediaUrl: statusType !== 'text' ? mediaUrl : undefined,
        mediaName: statusType !== 'text' ? mediaName : undefined,
        audioDuration: statusType === 'audio' ? audioDuration : undefined,
        backgroundColor,
        textColor: '#ffffff',
        fontStyle,
        targetType: targetMode === 'all' ? 'all' : 'specific',
        targetGroupJids: activeTargetGroups.map(g => g.jid),
        excludedGroupJids: groups.filter(g => g.isExcluded).map(g => g.jid),
        scheduledFor: scheduledIso,
        recurrence,
        status: 'scheduled',
        dmReportSent: sendDmReport,
      });

      confetti({
        particleCount: 60,
        spread: 60,
        origin: { y: 0.6 }
      });

      setSuccessToast(`Broadcast successfully scheduled for ${scheduledDate || 'selected time'} at ${scheduledTime} to ${activeTargetGroups.length} groups!`);
      setTimeout(() => setSuccessToast(null), 5000);
      setIsScheduled(false);
      return;
    }

    // Immediate Broadcast Simulation
    setIsSending(true);
    setSendProgress(0);
    setSendingGroupIndex(0);

    const totalSteps = activeTargetGroups.length;
    let step = 0;

    const interval = setInterval(() => {
      step++;
      setSendingGroupIndex(step);
      setSendProgress(Math.round((step / totalSteps) * 100));

      if (step >= totalSteps) {
        clearInterval(interval);
        setTimeout(() => {
          setIsSending(false);
          
          confetti({
            particleCount: 90,
            spread: 70,
            origin: { y: 0.6 }
          });

          onPostStatus({
            type: statusType,
            content,
            mediaUrl: statusType !== 'text' ? mediaUrl : undefined,
            mediaName: statusType !== 'text' ? mediaName : undefined,
            audioDuration: statusType === 'audio' ? audioDuration : undefined,
            backgroundColor,
            textColor: '#ffffff',
            fontStyle,
            targetType: targetMode === 'all' ? 'all' : 'specific',
            targetGroupJids: activeTargetGroups.map(g => g.jid),
            excludedGroupJids: groups.filter(g => g.isExcluded).map(g => g.jid),
            scheduledFor: undefined,
            recurrence: 'once',
            status: 'posted',
            dmReportSent: sendDmReport,
          });

          setSuccessToast(`Successfully broadcasted WhatsApp Group Status to ${activeTargetGroups.length} groups! Daily DM report updated.`);
          setTimeout(() => setSuccessToast(null), 5000);
        }, 500);
      }
    }, 320);
  };

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Composer Form (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-6 md:p-8 shadow-[0_4px_25px_-5px_rgba(0,0,0,0.05)] border border-gray-100">
          
          {/* Header & Quota Info */}
          <div className="flex flex-wrap items-center justify-between gap-4 pb-5 border-b border-gray-100 mb-6">
            <div>
              <h2 className="text-xl font-bold text-gray-900 tracking-tight flex items-center gap-2">
                <span>Compose Group Status</span>
                <span className="text-[11px] font-semibold bg-brand-light text-brand px-2.5 py-0.5 rounded-full border border-brand/20">
                  Native WhatsApp Updates
                </span>
              </h2>
              <p className="text-xs text-gray-500 mt-0.5">
                Send native group statuses to all connected group JIDs with color backgrounds, fonts & scheduling
              </p>
            </div>

            <div className="bg-gray-50 px-3 py-1.5 rounded-xl border border-gray-200/80 flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-600" />
              <div className="text-right">
                <div className="text-[10px] text-gray-400 font-medium">Session Quota</div>
                <div className="text-xs font-bold text-gray-800">{statusQuotasRemaining} broadcasts left</div>
              </div>
            </div>
          </div>

          {/* Status Type Selector */}
          <div className="mb-6">
            <label className="block text-xs font-bold text-gray-700 mb-2 uppercase tracking-wider">
              Status Media Type
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { id: 'text', label: 'Text Status', icon: Type, desc: '18 Colors + Fonts' },
                { id: 'image', label: 'Image Flyer', icon: ImageIcon, desc: 'HD + Caption' },
                { id: 'video', label: 'Video Story', icon: Video, desc: '30s Clip' },
                { id: 'audio', label: 'Voice Note', icon: Mic, desc: 'Audio Waveform' },
              ].map(item => {
                const Icon = item.icon;
                const active = statusType === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setStatusType(item.id as StatusMediaType)}
                    className={`p-3 rounded-xl border flex flex-col items-center text-center transition-all ${
                      active
                        ? 'bg-brand/10 border-brand text-brand shadow-sm ring-1 ring-brand/30'
                        : 'bg-gray-50/70 border-gray-200 text-gray-600 hover:bg-gray-100/80'
                    }`}
                  >
                    <Icon className="w-5 h-5 mb-1" />
                    <span className="text-xs font-bold">{item.label}</span>
                    <span className="text-[10px] opacity-70 hidden sm:inline">{item.desc}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Text & Caption Input */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold text-gray-700 uppercase tracking-wider">
                {statusType === 'text' ? 'Status Text Content' : 'Media Caption'}
              </label>
              <span className="text-[11px] text-gray-400 font-mono">
                {content.length}/700 chars
              </span>
            </div>

            <textarea
              rows={statusType === 'text' ? 4 : 2}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder={statusType === 'text' ? 'Type your WhatsApp group status update...' : 'Add a caption for this media story...'}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-brand/40 focus:border-brand transition leading-relaxed"
            ></textarea>

            {/* Quick Emoji / Snippet Shortcuts */}
            <div className="flex flex-wrap items-center gap-1.5 mt-2">
              <span className="text-[11px] text-gray-400 mr-1">Quick add:</span>
              {['🔥 FLASH SALE', '📢 ANNOUNCEMENT', '🚀 NEW LAUNCH', '⚡ ALERT', '✅ UPDATE', '💰 DISCOUNT'].map((snippet, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setContent(prev => prev ? `${prev} ${snippet} ` : `${snippet} `)}
                  className="text-[11px] bg-gray-100 hover:bg-brand-light hover:text-brand px-2 py-0.5 rounded-md text-gray-600 transition"
                >
                  {snippet}
                </button>
              ))}
            </div>
          </div>

          {/* If Text Status: 18 WhatsApp Colors & Font Selectors */}
          {(statusType === 'text' || statusType === 'audio') && (
            <div className="mb-6 p-4 rounded-xl bg-gray-50/80 border border-gray-100 space-y-4">
              {/* 18 Color Swatches */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-gray-800 flex items-center gap-1.5">
                    <Palette className="w-3.5 h-3.5 text-brand" /> 18 WhatsApp Background Colors
                  </span>
                  <span className="text-[10px] text-gray-500 font-mono">{backgroundColor}</span>
                </div>
                
                <div className="grid grid-cols-9 sm:grid-cols-18 gap-1.5">
                  {WHATSAPP_18_COLORS.map((c) => {
                    const isSelected = backgroundColor.toLowerCase() === c.hex.toLowerCase();
                    return (
                      <button
                        key={c.id}
                        type="button"
                        title={c.name}
                        onClick={() => handleColorSelect(c.hex)}
                        className={`w-7 h-7 rounded-lg transition-transform flex items-center justify-center shadow-xs ${
                          isSelected ? 'scale-115 ring-2 ring-brand ring-offset-2 z-10' : 'hover:scale-105'
                        }`}
                        style={{ backgroundColor: c.hex }}
                      >
                        {isSelected && <Check className="w-3.5 h-3.5 text-white stroke-[3]" />}
                      </button>
                    );
                  })}
                </div>

                {/* Custom Hex Code input */}
                <div className="flex items-center gap-2 mt-3 pt-2 border-t border-gray-200/60">
                  <span className="text-[11px] text-gray-500">Custom Hex:</span>
                  <input
                    type="text"
                    value={customHex}
                    onChange={handleCustomHexChange}
                    placeholder="#5a49ff"
                    className="w-24 px-2 py-1 text-xs font-mono rounded border border-gray-200 focus:outline-none focus:ring-1 focus:ring-brand uppercase"
                  />
                  <div 
                    className="w-5 h-5 rounded border border-gray-200 shadow-inner" 
                    style={{ backgroundColor }}
                  ></div>
                </div>
              </div>

              {/* Font Style Picker */}
              <div>
                <span className="text-xs font-bold text-gray-800 block mb-2">Typography & Font Family</span>
                <div className="grid grid-cols-5 gap-1.5">
                  {[
                    { id: 'sans', label: 'Clean Sans', style: 'font-sans' },
                    { id: 'bold', label: 'Impact Bold', style: 'font-extrabold' },
                    { id: 'serif', label: 'Classic Serif', style: 'font-serif' },
                    { id: 'mono', label: 'Terminal Code', style: 'font-mono' },
                    { id: 'handwriting', label: 'Casual Script', style: 'font-handwriting' },
                  ].map(f => (
                    <button
                      key={f.id}
                      type="button"
                      onClick={() => setFontStyle(f.id as any)}
                      className={`py-1.5 px-2 rounded-lg text-xs border text-center transition ${
                        fontStyle === f.id
                          ? 'bg-brand text-white border-brand font-bold shadow-xs'
                          : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-100'
                      }`}
                    >
                      <span className={f.style}>{f.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* If Image/Video/Audio: Media Upload & Presets */}
          {statusType !== 'text' && (
            <div className="mb-6 p-4 rounded-xl bg-gray-50 border border-gray-200 space-y-3">
              <span className="text-xs font-bold text-gray-800 block">
                Upload or Select {statusType.toUpperCase()} Asset
              </span>

              <div className="flex flex-col sm:flex-row gap-3">
                <label className="flex-1 flex flex-col items-center justify-center p-4 border-2 border-dashed border-gray-300 rounded-xl bg-white hover:border-brand cursor-pointer transition">
                  <Upload className="w-6 h-6 text-brand mb-1" />
                  <span className="text-xs font-bold text-gray-700">Choose custom {statusType}</span>
                  <span className="text-[10px] text-gray-400">Click to browse or drag & drop</span>
                  <input 
                    type="file" 
                    accept={statusType === 'image' ? 'image/*' : statusType === 'video' ? 'video/*' : 'audio/*'} 
                    className="hidden" 
                    onChange={handleFileUpload} 
                  />
                </label>

                {/* Sample Media Presets */}
                <div className="flex-1 space-y-1.5">
                  <span className="text-[11px] font-semibold text-gray-500 block">Sample Presets:</span>
                  {statusType === 'image' && (
                    <div className="space-y-1">
                      <button
                        type="button"
                        onClick={() => handlePresetMedia('https://images.unsplash.com/photo-1557804506-669a67965ba0?w=800&q=80', 'launch-flyer.jpg', 'image')}
                        className="w-full text-left text-xs p-1.5 bg-white rounded border border-gray-200 hover:border-brand flex items-center justify-between"
                      >
                        <span>🚀 Tech Launch Banner</span>
                        <span className="text-[10px] text-brand">Use</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handlePresetMedia('https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=800&q=80', 'cargo-stock.jpg', 'image')}
                        className="w-full text-left text-xs p-1.5 bg-white rounded border border-gray-200 hover:border-brand flex items-center justify-between"
                      >
                        <span>📦 Cargo Wholesale Shipment</span>
                        <span className="text-[10px] text-brand">Use</span>
                      </button>
                    </div>
                  )}
                  {statusType === 'video' && (
                    <button
                      type="button"
                      onClick={() => handlePresetMedia('https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=800&q=80', 'promo-clip.mp4', 'video')}
                      className="w-full text-left text-xs p-2 bg-white rounded border border-gray-200 hover:border-brand flex items-center justify-between"
                    >
                      <span>🎬 High-Impact 30s Promo Video</span>
                      <span className="text-[10px] text-brand">Use</span>
                    </button>
                  )}
                  {statusType === 'audio' && (
                    <button
                      type="button"
                      onClick={() => {
                        setAudioDuration('0:42');
                        setMediaName('voice-announcement.opus');
                      }}
                      className="w-full text-left text-xs p-2 bg-white rounded border border-gray-200 hover:border-brand flex items-center justify-between"
                    >
                      <span>🎙️ Voice Note (0:42 waveform)</span>
                      <span className="text-[10px] text-brand">Active</span>
                    </button>
                  )}
                </div>
              </div>
              {mediaName && (
                <div className="text-[11px] text-gray-500 flex items-center gap-1.5 bg-white p-2 rounded border border-gray-200">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Selected file: <strong className="text-gray-800">{mediaName}</strong></span>
                </div>
              )}
            </div>
          )}

          {/* Target Broadcast Selection */}
          <div className="mb-6">
            <label className="block text-xs font-bold text-gray-700 mb-2 uppercase tracking-wider">
              Broadcast Target Routing
            </label>
            
            <div className="grid grid-cols-2 gap-3 mb-3">
              <button
                type="button"
                onClick={() => setTargetMode('all')}
                className={`p-3 rounded-xl border text-left flex items-start gap-2.5 transition ${
                  targetMode === 'all'
                    ? 'bg-brand/10 border-brand text-brand ring-1 ring-brand/30'
                    : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Radio className="w-4 h-4 mt-0.5 shrink-0" />
                <div>
                  <div className="text-xs font-bold">Broadcast to All Groups</div>
                  <div className="text-[10px] text-gray-500">
                    {groups.filter(g => !g.isExcluded).length} groups targeted ({excludedGroupsCount} excluded)
                  </div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setTargetMode('specific')}
                className={`p-3 rounded-xl border text-left flex items-start gap-2.5 transition ${
                  targetMode === 'specific'
                    ? 'bg-brand/10 border-brand text-brand ring-1 ring-brand/30'
                    : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                }`}
              >
                <CheckSquare className="w-4 h-4 mt-0.5 shrink-0" />
                <div>
                  <div className="text-xs font-bold">Custom Select JIDs</div>
                  <div className="text-[10px] text-gray-500">
                    {selectedJids.length} of {groups.length} groups selected
                  </div>
                </div>
              </button>
            </div>

            {/* Group Checklist (if specific mode) */}
            {targetMode === 'specific' && (
              <div className="p-3 bg-gray-50 rounded-xl border border-gray-200 max-h-48 overflow-y-auto space-y-1.5">
                <div className="flex justify-between items-center pb-2 mb-1 border-b border-gray-200 text-[11px]">
                  <span className="font-semibold text-gray-600">Select Groups:</span>
                  <div className="flex gap-2 text-brand">
                    <button type="button" onClick={handleSelectAllJids} className="hover:underline">Select all</button>
                    <span>·</span>
                    <button type="button" onClick={handleDeselectAllJids} className="hover:underline">Clear</button>
                  </div>
                </div>

                {groups.map(group => {
                  const isChecked = selectedJids.includes(group.jid);
                  return (
                    <label 
                      key={group.id} 
                      className={`flex items-center justify-between p-2 rounded-lg text-xs cursor-pointer transition ${
                        isChecked ? 'bg-white shadow-xs border border-gray-200' : 'hover:bg-gray-100/80 text-gray-600'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => handleToggleJid(group.jid)}
                          className="rounded text-brand focus:ring-brand w-3.5 h-3.5"
                        />
                        <span className="font-medium text-gray-800">{group.name}</span>
                      </div>
                      <span className="text-[10px] font-mono text-gray-400">{group.membersCount} members</span>
                    </label>
                  );
                })}
              </div>
            )}
          </div>

          {/* Schedule & Daily DM Report Options */}
          <div className="mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-3.5 rounded-xl bg-gray-50/70 border border-gray-200/80 text-xs">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={sendDmReport}
                onChange={(e) => setSendDmReport(e.target.checked)}
                className="rounded text-brand focus:ring-brand w-4 h-4"
              />
              <span className="text-gray-700 font-medium">
                Send confirmation & summary to my WhatsApp DM
              </span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={isScheduled}
                onChange={(e) => {
                  const checked = e.target.checked;
                  setIsScheduled(checked);
                  if (checked && !scheduledDate) {
                    setScheduledDate(new Date().toISOString().split('T')[0]);
                  }
                }}
                className="rounded text-brand focus:ring-brand w-4 h-4"
              />
              <span className="text-gray-700 font-bold flex items-center gap-1 text-brand">
                <Clock className="w-3.5 h-3.5" /> Schedule Status for Later
              </span>
            </label>
          </div>

          {/* ADVANCED SCHEDULING CONTROLS */}
          {isScheduled && (
            <div className="mb-6 p-4 bg-gradient-to-br from-brand-light/60 to-purple-50 rounded-2xl border border-brand/25 space-y-3.5 animate-fadeIn">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-brand-dark flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-brand" />
                  Select Broadcast Date & Time
                </span>
                <span className="text-[10px] font-mono text-brand bg-white px-2 py-0.5 rounded border border-brand/20">
                  Local Device Timezone
                </span>
              </div>

              {/* Quick Preset Buttons */}
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-[10px] text-gray-500 mr-1">Quick Picks:</span>
                <button
                  type="button"
                  onClick={() => setQuickSchedule('plus1h')}
                  className="text-[11px] bg-white hover:bg-brand hover:text-white px-2.5 py-1 rounded-lg border border-brand/20 text-gray-700 transition"
                >
                  +1 Hour
                </button>
                <button
                  type="button"
                  onClick={() => setQuickSchedule('todayPrime')}
                  className="text-[11px] bg-white hover:bg-brand hover:text-white px-2.5 py-1 rounded-lg border border-brand/20 text-gray-700 transition"
                >
                  🔥 Tonight Peak 8:30 PM
                </button>
                <button
                  type="button"
                  onClick={() => setQuickSchedule('tomorrowMorning')}
                  className="text-[11px] bg-white hover:bg-brand hover:text-white px-2.5 py-1 rounded-lg border border-brand/20 text-gray-700 transition"
                >
                  Tomorrow 9:00 AM
                </button>
                <button
                  type="button"
                  onClick={() => setQuickSchedule('tomorrowPrime')}
                  className="text-[11px] bg-white hover:bg-brand hover:text-white px-2.5 py-1 rounded-lg border border-brand/20 text-gray-700 transition"
                >
                  Tomorrow 8:00 PM
                </button>
              </div>

              {/* Date & Time Selectors */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <div>
                  <label className="block text-[11px] font-bold text-gray-700 mb-1">Date</label>
                  <input
                    type="date"
                    value={scheduledDate}
                    onChange={(e) => setScheduledDate(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-brand/30 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-brand font-medium"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-gray-700 mb-1">Time</label>
                  <input
                    type="time"
                    value={scheduledTime}
                    onChange={(e) => setScheduledTime(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-brand/30 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-brand font-medium"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-gray-700 mb-1">Recurrence</label>
                  <select
                    value={recurrence}
                    onChange={(e) => setRecurrence(e.target.value as any)}
                    className="w-full px-3 py-2 bg-white border border-brand/30 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-brand font-medium"
                  >
                    <option value="once">Once (Single Run)</option>
                    <option value="daily">Daily at this time</option>
                    <option value="weekly">Weekly</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center gap-1.5 text-[11px] text-gray-600 bg-white/70 p-2 rounded-lg border border-brand/15">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>
                  Will queue into Baileys socket scheduler and broadcast automatically to <strong>{activeTargetGroups.length} groups</strong>.
                </span>
              </div>
            </div>
          )}

          {/* Progress Bar (when sending) */}
          {isSending && (
            <div className="mb-6 p-4 rounded-xl bg-brand-light border border-brand/30 animate-pulse">
              <div className="flex justify-between text-xs font-bold text-brand mb-1.5">
                <span>Broadcasting Baileys Group Status packets...</span>
                <span>{sendProgress}%</span>
              </div>
              <div className="w-full bg-brand/20 rounded-full h-2 overflow-hidden mb-2">
                <div 
                  className="bg-brand h-full transition-all duration-300 rounded-full" 
                  style={{ width: `${sendProgress}%` }}
                ></div>
              </div>
              <div className="text-[11px] text-gray-600 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                Transmitting to group JID: <code className="font-mono font-bold text-gray-800">{activeTargetGroups[sendingGroupIndex - 1]?.name || 'Initializing socket...'}</code>
              </div>
            </div>
          )}

          {/* Success Toast */}
          {successToast && (
            <div className="mb-6 p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2 animate-fadeIn font-semibold">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{successToast}</span>
            </div>
          )}

          {/* Submit Broadcast Button */}
          <button
            type="button"
            disabled={isSending || activeTargetGroups.length === 0}
            onClick={handleBroadcast}
            className={`w-full py-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-md ${
              isSending
                ? 'bg-gray-400 text-white cursor-not-allowed'
                : isScheduled
                  ? 'bg-purple-700 hover:bg-purple-800 text-white hover:shadow-lg active:scale-[0.99]'
                  : 'bg-brand hover:bg-brand-dark text-white hover:shadow-lg active:scale-[0.99]'
            }`}
          >
            {isScheduled ? <Clock className="w-4 h-4" /> : <Send className="w-4 h-4" />}
            {isScheduled 
              ? `Schedule Status for ${scheduledDate || 'Today'} at ${scheduledTime} (${activeTargetGroups.length} Groups)` 
              : `Broadcast Group Status Now (${activeTargetGroups.length} Groups)`}
          </button>
        </div>

        {/* Right Live Phone Preview (5 cols) */}
        <div className="lg:col-span-5 flex flex-col items-center">
          <StatusPhonePreview
            type={statusType}
            content={content}
            mediaUrl={mediaUrl}
            audioDuration={audioDuration}
            backgroundColor={backgroundColor}
            textColor="#ffffff"
            fontStyle={fontStyle}
            targetGroupName={activeTargetGroups[0]?.name || 'Usman Tech Founders VIP'}
            totalDelivered={activeTargetGroups.length}
            viewCount={1840}
            onCycleFont={handleCycleFont}
            onQuickColorChange={handleColorSelect}
          />
        </div>
      </div>

      {/* Scheduled Queue Section */}
      {scheduledStatuses.length > 0 && onDispatchScheduledNow && onCancelScheduled && onRescheduleStatus && (
        <div className="bg-white rounded-2xl p-6 md:p-8 shadow-[0_4px_25px_-5px_rgba(0,0,0,0.05)] border border-gray-100">
          <ScheduledQueueManager
            scheduledStatuses={scheduledStatuses}
            onDispatchNow={onDispatchScheduledNow}
            onCancelScheduled={onCancelScheduled}
            onReschedule={onRescheduleStatus}
          />
        </div>
      )}
    </div>
  );
};
