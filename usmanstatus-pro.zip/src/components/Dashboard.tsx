import React, { useState } from 'react';
import { 
  Hexagon, ArrowLeft, Send, Users, BarChart2, KeyRound, 
  Smartphone, ShieldCheck, BatteryCharging, Wifi, Sparkles, RefreshCw, 
  LayoutGrid, CheckCircle2, Clock, LogIn, LogOut, Cloud, CloudOff
} from 'lucide-react';
import { User } from 'firebase/auth';
import { WhatsAppGroup, WhatsAppStatus, DMReport, TokenRecord, UserSession } from '../types';
import { StatusComposer } from './StatusComposer';
import { GroupsManager } from './GroupsManager';
import { AnalyticsReports } from './AnalyticsReports';
import { SessionTokenManager } from './SessionTokenManager';

interface DashboardProps {
  user: User | null;
  firestoreConnected: boolean;
  onSignInWithGoogle: () => Promise<void>;
  onSignOut: () => Promise<void>;
  session: UserSession;
  groups: WhatsAppGroup[];
  statuses: WhatsAppStatus[];
  dmReports: DMReport[];
  tokens: TokenRecord[];
  onBackToLanding: () => void;
  onPostStatus: (status: Omit<WhatsAppStatus, 'id' | 'createdAt' | 'viewCount' | 'totalDelivered' | 'totalTargeted'>) => void;
  onDispatchScheduledNow?: (statusId: string) => void;
  onCancelScheduled?: (statusId: string) => void;
  onRescheduleStatus?: (statusId: string, newTime: string) => void;
  onToggleExcludeGroup: (groupId: string) => void;
  onAddGroup: (group: Omit<WhatsAppGroup, 'id'>) => void;
  onBulkAddGroups?: (newGroups: Omit<WhatsAppGroup, 'id'>[]) => void;
  onSyncGroups: () => void;
  onSendTestDmReport: (phone: string) => void;
  onGenerateToken: (token: Omit<TokenRecord, 'id' | 'createdAt' | 'usedCount'>) => void;
  onRevokeToken: (tokenId: string) => void;
  onRefreshSession: () => void;
  onSwitchToken: (tokenCode: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  user,
  firestoreConnected,
  onSignInWithGoogle,
  onSignOut,
  session,
  groups,
  statuses,
  dmReports,
  tokens,
  onBackToLanding,
  onPostStatus,
  onDispatchScheduledNow,
  onCancelScheduled,
  onRescheduleStatus,
  onToggleExcludeGroup,
  onAddGroup,
  onBulkAddGroups,
  onSyncGroups,
  onSendTestDmReport,
  onGenerateToken,
  onRevokeToken,
  onRefreshSession,
  onSwitchToken,
}) => {
  const [activeTab, setActiveTab] = useState<'composer' | 'groups' | 'analytics' | 'session'>('composer');

  const activeGroupsCount = groups.filter(g => !g.isExcluded).length;
  const scheduledStatuses = statuses.filter(s => s.status === 'scheduled');
  const postedStatuses = statuses.filter(s => s.status === 'posted');

  return (
    <div className="min-h-screen bg-[#fbfcff] flex flex-col font-sans text-gray-900 selection:bg-brand/15 selection:text-brand-dark">
      
      {/* Top App Bar */}
      <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-gray-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          
          {/* Brand & Back Button */}
          <div className="flex items-center gap-3">
            <button
              onClick={onBackToLanding}
              className="p-2 hover:bg-gray-100 rounded-xl text-gray-500 hover:text-gray-900 transition flex items-center gap-1.5 text-xs font-semibold"
              title="Return to Home Landing"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="hidden sm:inline">Landing</span>
            </button>

            <div className="h-5 w-[1px] bg-gray-200 hidden sm:block"></div>

            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-brand flex items-center justify-center text-white shadow-xs">
                <Hexagon className="w-5 h-5 fill-current" />
              </div>
              <div>
                <span className="font-bold text-base tracking-tight text-gray-900 block leading-tight">
                  UsmanStatus Pro
                </span>
                <span className="text-[10px] text-gray-400 font-mono hidden md:block">
                  v3.4 Baileys Multi-Device · Firebase Cloud
                </span>
              </div>
            </div>
          </div>

          {/* Session & Firebase Status Pills */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Cloud Firestore Indicator */}
            <div className={`hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold border ${
              firestoreConnected 
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
                : 'bg-amber-50 text-amber-700 border-amber-200'
            }`}>
              <Cloud className="w-3.5 h-3.5 text-emerald-600" />
              <span>Firestore Synced</span>
            </div>

            {/* User Auth or Google Sign In */}
            {user ? (
              <div className="flex items-center gap-2 bg-gray-50 border border-gray-200 pl-2 pr-3 py-1 rounded-full text-xs text-gray-700">
                {user.photoURL ? (
                  <img src={user.photoURL} alt={user.displayName || 'User'} className="w-5 h-5 rounded-full" referrerPolicy="no-referrer" />
                ) : (
                  <div className="w-5 h-5 rounded-full bg-brand text-white text-[10px] flex items-center justify-center font-bold">
                    {(user.displayName || 'U')[0]}
                  </div>
                )}
                <span className="font-medium max-w-[100px] truncate hidden sm:inline">{user.displayName || user.email}</span>
                <button
                  onClick={onSignOut}
                  title="Sign out of Firebase"
                  className="text-gray-400 hover:text-rose-600 transition ml-1"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={onSignInWithGoogle}
                className="flex items-center gap-1.5 bg-white hover:bg-gray-50 border border-gray-200 text-gray-700 px-3 py-1.5 rounded-full text-xs font-semibold shadow-xs transition"
              >
                <LogIn className="w-3.5 h-3.5 text-brand" />
                <span>Google Sign-In</span>
              </button>
            )}

            <div className="hidden lg:flex items-center gap-2 bg-emerald-50 border border-emerald-200/80 px-3 py-1.5 rounded-full text-xs text-emerald-800 font-medium">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <Smartphone className="w-3.5 h-3.5 text-emerald-600" />
              <span>{session.userPhone}</span>
              <span className="text-emerald-500 text-[10px] font-mono">({session.batteryLevel}%)</span>
            </div>

            <div className="flex items-center gap-2 bg-brand-light border border-brand/20 px-3 py-1.5 rounded-full text-xs text-brand font-semibold">
              <KeyRound className="w-3.5 h-3.5 text-brand" />
              <span className="font-mono text-[11px] truncate max-w-[110px] sm:max-w-none">{session.token}</span>
            </div>
          </div>
        </div>

        {/* Navigation Tabs Bar */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center gap-1 sm:gap-2 overflow-x-auto border-t border-gray-100 py-1.5">
          {[
            { 
              id: 'composer', 
              label: 'Status Composer & Preview', 
              icon: Send, 
              badge: scheduledStatuses.length > 0 ? `${scheduledStatuses.length} Queued` : null 
            },
            { 
              id: 'groups', 
              label: 'Groups & JIDs (Bulk Upload)', 
              icon: Users, 
              badge: `${activeGroupsCount} Active` 
            },
            { 
              id: 'analytics', 
              label: 'Analytics & DM Reports', 
              icon: BarChart2, 
              badge: `${postedStatuses.length} Posts` 
            },
            { 
              id: 'session', 
              label: 'Session & Tokens', 
              icon: KeyRound, 
              badge: session.role.toUpperCase() 
            },
          ].map(tab => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 whitespace-nowrap transition-all ${
                  active
                    ? 'bg-brand text-white shadow-sm'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-md font-semibold ${
                    active ? 'bg-white/20 text-white' : 'bg-gray-200 text-gray-700'
                  }`}>
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </header>

      {/* Main Dashboard Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 md:py-8">
        {activeTab === 'composer' && (
          <StatusComposer
            groups={groups}
            scheduledStatuses={scheduledStatuses}
            onPostStatus={onPostStatus}
            onDispatchScheduledNow={onDispatchScheduledNow}
            onCancelScheduled={onCancelScheduled}
            onRescheduleStatus={onRescheduleStatus}
            statusQuotasRemaining={session.statusQuotasRemaining}
          />
        )}

        {activeTab === 'groups' && (
          <GroupsManager
            groups={groups}
            onToggleExclude={onToggleExcludeGroup}
            onAddGroup={onAddGroup}
            onBulkAddGroups={onBulkAddGroups}
            onSyncGroups={onSyncGroups}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsReports
            statuses={statuses}
            dmReports={dmReports}
            recipientPhone={session.userPhone}
            onSendTestDmReport={onSendTestDmReport}
          />
        )}

        {activeTab === 'session' && (
          <SessionTokenManager
            session={session}
            tokens={tokens}
            onGenerateToken={onGenerateToken}
            onRevokeToken={onRevokeToken}
            onRefreshSession={onRefreshSession}
            onSwitchToken={onSwitchToken}
          />
        )}
      </main>

      {/* Dashboard Footer */}
      <footer className="border-t border-gray-200/80 bg-white py-4 px-6 text-center text-xs text-gray-400">
        UsmanStatus Pro Baileys Protocol &copy; 2026 · Token-Gated Session: <code className="font-mono text-gray-600 font-bold">{session.token}</code> · Connected to Cloud Firestore
      </footer>
    </div>
  );
};
