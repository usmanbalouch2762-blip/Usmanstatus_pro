import React from 'react';
import { X, CheckCircle2, QrCode, KeyRound, Radio, BarChart3, ArrowRight } from 'lucide-react';

interface HowItWorksModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenDashboard: () => void;
}

export const HowItWorksModal: React.FC<HowItWorksModalProps> = ({ isOpen, onClose, onOpenDashboard }) => {
  if (!isOpen) return null;

  const steps = [
    {
      step: '01',
      title: 'Redeem Access Token',
      description: 'Enter your one-time or multi-device authorization token provided by the administrator to unlock your secure session container.',
      icon: KeyRound,
      color: 'bg-brand/10 text-brand',
    },
    {
      step: '02',
      title: 'Pair WhatsApp Session',
      description: 'Scan the multi-device WhatsApp QR code in the dashboard to link your WhatsApp number safely with end-to-end encrypted session persistence.',
      icon: QrCode,
      color: 'bg-emerald-50 text-emerald-600',
    },
    {
      step: '03',
      title: 'Compose & Target Statuses',
      description: 'Create rich text with 18 WhatsApp background colors, upload high-res images, video reels, or voice notes. Target all groups or pick specific JIDs.',
      icon: Radio,
      color: 'bg-blue-50 text-blue-600',
    },
    {
      step: '04',
      title: 'Instant Broadcast & DM Reports',
      description: 'The worker transmits actual native WhatsApp group status packets without spamming message chats. Detailed daily analytics are delivered directly to your DM.',
      icon: BarChart3,
      color: 'bg-purple-50 text-purple-600',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 md:p-8 shadow-2xl border border-gray-100 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-4 border-b border-gray-100 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-brand flex items-center justify-center text-white font-bold text-sm">
              UP
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900">How UsmanStatus Pro Works</h3>
              <p className="text-xs text-gray-500">Autonomous WhatsApp Group Status protocol engine</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-gray-700 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 mb-8">
          {steps.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div key={idx} className="flex gap-4 p-4 rounded-xl bg-gray-50/80 border border-gray-100/80 hover:bg-white hover:shadow-md transition-all">
                <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${item.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-bold text-brand uppercase tracking-wider">Step {item.step}</span>
                    <h4 className="font-bold text-gray-900 text-sm">{item.title}</h4>
                  </div>
                  <p className="text-xs text-gray-600 leading-relaxed">{item.description}</p>
                </div>
              </div>
            );
          })}
        </div>

        <div className="bg-brand-light border border-brand/20 rounded-xl p-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-brand shrink-0" />
            <span className="text-xs font-semibold text-gray-800">Ready to test? Try our live demo dashboard instantly.</span>
          </div>
          <button
            onClick={() => {
              onClose();
              onOpenDashboard();
            }}
            className="bg-brand hover:bg-brand-dark text-white px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors shrink-0 shadow-sm"
          >
            Launch Dashboard <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
