import React, { useState, useEffect } from 'react';
import { 
  Play, Pause, Eye, Heart, MessageSquare, Volume2, ShieldCheck, 
  Sparkles, Smartphone, Maximize2, Minimize2, Flame, ThumbsUp, PartyPopper, RefreshCw
} from 'lucide-react';
import { StatusMediaType } from '../types';

interface StatusPhonePreviewProps {
  type: StatusMediaType;
  content: string;
  mediaUrl?: string;
  audioDuration?: string;
  backgroundColor: string;
  textColor: string;
  fontStyle: 'sans' | 'serif' | 'mono' | 'bold' | 'handwriting';
  targetGroupName?: string;
  totalDelivered?: number;
  viewCount?: number;
  onCycleFont?: () => void;
  onQuickColorChange?: (colorHex: string) => void;
}

export const StatusPhonePreview: React.FC<StatusPhonePreviewProps> = ({
  type,
  content,
  mediaUrl,
  audioDuration = '0:35',
  backgroundColor,
  textColor = '#ffffff',
  fontStyle,
  targetGroupName = 'Usman Tech Founders VIP',
  totalDelivered = 8,
  viewCount = 1842,
  onCycleFont,
  onQuickColorChange,
}) => {
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [progress, setProgress] = useState(45);
  const [floatingReactions, setFloatingReactions] = useState<{ id: number; emoji: string; x: number }[]>([]);
  const [activeStorySegment, setActiveStorySegment] = useState(0);
  const [simulatedViews, setSimulatedViews] = useState(viewCount);

  useEffect(() => {
    setSimulatedViews(viewCount);
  }, [viewCount]);

  useEffect(() => {
    let interval: any;
    if (isPlayingAudio) {
      interval = setInterval(() => {
        setProgress((prev) => (prev >= 100 ? 0 : prev + 4));
      }, 300);
    }
    return () => clearInterval(interval);
  }, [isPlayingAudio]);

  const triggerReaction = (emoji: string) => {
    const newId = Date.now() + Math.random();
    const xPos = 20 + Math.random() * 60; // percentage
    setFloatingReactions(prev => [...prev, { id: newId, emoji, x: xPos }]);
    setSimulatedViews(prev => prev + 1);

    setTimeout(() => {
      setFloatingReactions(prev => prev.filter(r => r.id !== newId));
    }, 1800);
  };

  const getFontFamily = () => {
    switch (fontStyle) {
      case 'serif':
        return 'font-serif font-medium';
      case 'mono':
        return 'font-mono font-medium';
      case 'bold':
        return 'font-black tracking-tight uppercase';
      case 'handwriting':
        return 'font-cursive italic tracking-wide';
      default:
        return 'font-sans font-semibold';
    }
  };

  // Dynamic text size based on character count for WhatsApp text status
  const getTextSizeClass = () => {
    const len = content.length;
    if (len <= 40) return 'text-2xl sm:text-3xl leading-snug font-bold';
    if (len <= 100) return 'text-xl sm:text-2xl leading-normal';
    if (len <= 220) return 'text-base sm:text-lg leading-relaxed';
    return 'text-sm sm:text-base leading-relaxed';
  };

  return (
    <div className="flex flex-col items-center w-full max-w-sm">
      {/* Top Banner */}
      <div className="flex items-center justify-between w-full mb-3 px-2">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
          </span>
          <span className="text-xs font-bold text-gray-800">
            Live WhatsApp Status Preview
          </span>
        </div>
        <span className="text-[10px] text-gray-500 font-mono bg-gray-100 px-2 py-0.5 rounded-full">
          {type === 'text' ? 'Text Status' : `${type.toUpperCase()} Story`}
        </span>
      </div>

      {/* Phone Shell */}
      <div className="w-[310px] h-[585px] bg-[#111b21] rounded-[42px] p-3 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.35)] border-[5px] border-gray-800 relative flex flex-col overflow-hidden select-none">
        
        {/* Dynamic Island / Speaker */}
        <div className="absolute top-4 left-1/2 -translate-x-1/2 w-28 h-4 bg-black rounded-full z-30 flex items-center justify-center pointer-events-none">
          <div className="w-2.5 h-2.5 rounded-full bg-gray-900 border border-gray-800 mr-2.5"></div>
          <div className="w-10 h-1 bg-gray-900 rounded-full"></div>
        </div>

        {/* Screen Canvas Area */}
        <div 
          className="w-full h-full rounded-[32px] overflow-hidden relative flex flex-col justify-between transition-colors duration-300"
          style={{ 
            backgroundColor: type === 'text' || type === 'audio' ? backgroundColor : '#0a0a0a',
            color: textColor 
          }}
        >
          {/* Top Status Bar & WhatsApp Story Progress */}
          <div className="z-20 pt-7 px-3.5 pb-2 bg-gradient-to-b from-black/70 via-black/30 to-transparent">
            {/* Story Segments Progress Bars */}
            <div className="flex gap-1.5 mb-2.5">
              <div 
                onClick={() => setActiveStorySegment(0)}
                className="h-1 flex-1 bg-white/30 rounded-full overflow-hidden cursor-pointer"
              >
                <div className="h-full bg-white transition-all duration-300 w-full"></div>
              </div>
              <div 
                onClick={() => setActiveStorySegment(1)}
                className="h-1 flex-1 bg-white/30 rounded-full overflow-hidden cursor-pointer"
              >
                <div className="h-full bg-white transition-all duration-300 w-1/3"></div>
              </div>
              <div 
                onClick={() => setActiveStorySegment(2)}
                className="h-1 flex-1 bg-white/30 rounded-full cursor-pointer"
              ></div>
            </div>

            {/* Profile Bar / Group Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-brand to-emerald-400 p-[1.5px] shrink-0">
                  <div className="w-full h-full rounded-full bg-gray-950 flex items-center justify-center text-white text-[11px] font-extrabold">
                    {targetGroupName ? targetGroupName.slice(0, 2).toUpperCase() : 'US'}
                  </div>
                </div>
                <div className="leading-tight">
                  <div className="text-[12px] font-bold text-white flex items-center gap-1 drop-shadow-sm truncate max-w-[140px]">
                    {targetGroupName}
                  </div>
                  <div className="text-[10px] text-white/80 flex items-center gap-1">
                    <span>Just now</span>
                    <span>·</span>
                    <span className="text-emerald-300 font-medium">Group Status</span>
                  </div>
                </div>
              </div>

              {/* Status Top Right Tools */}
              <div className="flex items-center gap-1">
                {type === 'text' && onCycleFont && (
                  <button
                    type="button"
                    onClick={onCycleFont}
                    title="Switch Font Style"
                    className="w-6 h-6 rounded-full bg-black/40 hover:bg-black/60 text-white flex items-center justify-center text-[10px] font-serif border border-white/20 transition active:scale-90"
                  >
                    T
                  </button>
                )}
                <div className="flex items-center gap-1 bg-black/40 backdrop-blur-md px-2 py-0.5 rounded-full border border-white/10 text-[9px] text-white font-medium">
                  <ShieldCheck className="w-2.5 h-2.5 text-emerald-400" />
                  <span>Baileys</span>
                </div>
              </div>
            </div>
          </div>

          {/* Floating Emoji Reactions Stream */}
          <div className="absolute inset-0 pointer-events-none z-30 overflow-hidden">
            {floatingReactions.map(r => (
              <div
                key={r.id}
                className="absolute text-2xl animate-floatUp"
                style={{
                  left: `${r.x}%`,
                  bottom: '80px',
                }}
              >
                {r.emoji}
              </div>
            ))}
          </div>

          {/* Status Main Body Content */}
          <div className="flex-1 flex flex-col items-center justify-center px-6 py-4 relative overflow-hidden text-center z-10">
            
            {/* TEXT STATUS PREVIEW */}
            {type === 'text' && (
              <div className="max-w-[260px] overflow-y-auto max-h-[340px] flex items-center justify-center p-2">
                <p 
                  className={`break-words tracking-tight text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.3)] transition-all duration-200 ${getFontFamily()} ${getTextSizeClass()}`}
                  style={{
                    textShadow: '0 2px 8px rgba(0,0,0,0.25)',
                  }}
                >
                  {content || 'Type your WhatsApp group status update here...'}
                </p>
              </div>
            )}

            {/* IMAGE STORY PREVIEW */}
            {type === 'image' && (
              <div className="absolute inset-0 flex flex-col justify-between">
                <img 
                  src={mediaUrl || 'https://images.unsplash.com/photo-1557804506-669a67965ba0?w=800&q=80'} 
                  alt="Status visual" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-black/35 pointer-events-none"></div>
                {content && (
                  <div className="absolute bottom-16 left-0 right-0 p-4 text-center z-10">
                    <p className="text-xs bg-black/60 backdrop-blur-md text-white py-2 px-3 rounded-xl inline-block max-w-[95%] leading-snug border border-white/15 shadow-md">
                      {content}
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* VIDEO STORY PREVIEW */}
            {type === 'video' && (
              <div className="absolute inset-0 flex flex-col justify-center items-center bg-black">
                <img 
                  src="https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=800&q=80" 
                  alt="Video thumbnail" 
                  className="w-full h-full object-cover opacity-75"
                />
                <div className="absolute w-14 h-14 bg-brand/80 backdrop-blur-md rounded-full flex items-center justify-center text-white shadow-xl cursor-pointer hover:scale-110 active:scale-95 transition-transform border border-white/30">
                  <Play className="w-6 h-6 ml-0.5 fill-current" />
                </div>
                <div className="absolute top-20 right-3 bg-black/70 px-2 py-0.5 rounded text-[9px] font-mono text-white border border-white/10">
                  0:15 / 0:30
                </div>
                {content && (
                  <div className="absolute bottom-16 left-0 right-0 p-4 text-center z-10">
                    <p className="text-xs bg-black/70 backdrop-blur-md text-white py-2 px-3 rounded-xl inline-block max-w-[95%] border border-white/15 shadow-md">
                      {content}
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* AUDIO / VOICE NOTE STATUS PREVIEW */}
            {type === 'audio' && (
              <div className="w-full max-w-[250px] bg-black/45 backdrop-blur-md p-4 rounded-2xl border border-white/20 text-white flex flex-col items-center gap-3 shadow-lg">
                <div className="flex items-center gap-3 w-full">
                  <button 
                    type="button"
                    onClick={() => setIsPlayingAudio(!isPlayingAudio)}
                    className="w-10 h-10 rounded-full bg-white text-gray-900 flex items-center justify-center shrink-0 shadow-md hover:scale-105 active:scale-95 transition"
                  >
                    {isPlayingAudio ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5 fill-current" />}
                  </button>
                  <div className="flex-1">
                    {/* Audio Waveform Bars */}
                    <div className="flex items-center gap-1 h-7">
                      {[30, 75, 45, 90, 60, 30, 85, 100, 50, 40, 75, 95, 60, 40, 85, 30, 65].map((h, i) => (
                        <div 
                          key={i} 
                          className={`w-1 rounded-full transition-all duration-200 ${
                            (i / 17) * 100 <= progress ? 'bg-white shadow-[0_0_8px_rgba(255,255,255,0.8)]' : 'bg-white/35'
                          }`}
                          style={{ height: `${Math.max(14, (h * (isPlayingAudio ? (0.7 + Math.random() * 0.3) : 1)) * 0.26)}px` }}
                        ></div>
                      ))}
                    </div>
                    <div className="flex justify-between text-[10px] text-white/80 mt-1 font-mono">
                      <span>{isPlayingAudio ? '0:14' : '0:00'}</span>
                      <span>{audioDuration}</span>
                    </div>
                  </div>
                </div>
                {content && (
                  <p className="text-xs text-center text-white/95 leading-snug font-medium">
                    {content}
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Bottom WhatsApp Actions & Reaction Pill Bar */}
          <div className="z-20 p-3 bg-gradient-to-t from-black/85 via-black/40 to-transparent flex flex-col gap-2">
            
            {/* View Metrics Pill */}
            <div className="flex items-center justify-between text-white text-[11px] px-1">
              <div className="flex items-center gap-1.5 bg-black/50 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/15 shadow-xs">
                <Eye className="w-3.5 h-3.5 text-emerald-400" />
                <span className="font-bold text-white">{simulatedViews.toLocaleString()}</span>
                <span className="text-white/80 text-[10px]">views</span>
              </div>
              <div className="text-white/80 text-[10px] bg-black/40 backdrop-blur-sm px-2 py-0.5 rounded-full border border-white/10">
                To {totalDelivered} groups
              </div>
            </div>

            {/* Interactive WhatsApp Reply / Reaction Bar */}
            <div className="w-full bg-white/20 backdrop-blur-md border border-white/30 rounded-full py-1.5 px-3 flex items-center justify-between text-white text-xs shadow-sm">
              <span className="text-white/75 text-[11px] pl-1 truncate">Reply to status...</span>
              
              {/* Quick Reactions */}
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => triggerReaction('🔥')}
                  className="p-1 hover:scale-125 active:scale-95 transition text-xs"
                  title="React with Fire"
                >
                  🔥
                </button>
                <button
                  type="button"
                  onClick={() => triggerReaction('❤️')}
                  className="p-1 hover:scale-125 active:scale-95 transition text-xs"
                  title="React with Heart"
                >
                  ❤️
                </button>
                <button
                  type="button"
                  onClick={() => triggerReaction('👏')}
                  className="p-1 hover:scale-125 active:scale-95 transition text-xs"
                  title="React with Claps"
                >
                  👏
                </button>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Preview Sub-Controls & Interactive Swatches */}
      <div className="mt-4 w-full bg-white rounded-xl p-3 border border-gray-200/80 shadow-xs flex items-center justify-between gap-2">
        <span className="text-[11px] font-bold text-gray-600">Background:</span>
        
        {/* Quick color dots */}
        <div className="flex items-center gap-1.5 overflow-x-auto">
          {['#7356bf', '#075e54', '#128c7e', '#9b1b30', '#c25e00', '#1f7a8c', '#2c3e50'].map(hex => (
            <button
              key={hex}
              type="button"
              onClick={() => onQuickColorChange?.(hex)}
              className={`w-5 h-5 rounded-full transition-transform border border-white shadow-xs ${
                backgroundColor.toLowerCase() === hex.toLowerCase() ? 'scale-125 ring-2 ring-brand' : 'hover:scale-110'
              }`}
              style={{ backgroundColor: hex }}
              title={`Use ${hex}`}
            />
          ))}
        </div>

        <span className="text-[10px] font-mono text-gray-400">{backgroundColor}</span>
      </div>
    </div>
  );
};
