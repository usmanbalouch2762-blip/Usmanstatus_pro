import React, { useState } from 'react';
import { 
  KeyRound, QrCode, Smartphone, ShieldCheck, Plus, 
  Trash2, RefreshCw, Copy, Check, Lock, Sparkles, BatteryCharging, Wifi
} from 'lucide-react';
import { TokenRecord, UserSession } from '../types';

interface SessionTokenManagerProps {
  session: UserSession;
  tokens: TokenRecord[];
  onGenerateToken: (token: Omit<TokenRecord, 'id' | 'createdAt' | 'usedCount'>) => void;
  onRevokeToken: (tokenId: string) => void;
  onRefreshSession: () => void;
  onSwitchToken: (tokenCode: string) => void;
}

export const SessionTokenManager: React.FC<SessionTokenManagerProps> = ({
  session,
  tokens,
  onGenerateToken,
  onRevokeToken,
  onRefreshSession,
  onSwitchToken,
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [newLabel, setNewLabel] = useState('');
  const [newClient, setNewClient] = useState('');
  const [newLimit, setNewLimit] = useState(100);
  const [newRole, setNewRole] = useState<'user' | 'admin'>('user');
  const [copiedToken, setCopiedToken] = useState<string | null>(null);
  const [showQrModal, setShowQrModal] = useState(false);
  const [isReconnecting, setIsReconnecting] = useState(false);

  const handleCopy = (t: string) => {
    navigator.clipboard.writeText(t);
    setCopiedToken(t);
    setTimeout(() => setCopiedToken(null), 2000);
  };

  const handleCreateToken = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLabel || !newClient) return;

    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const generatedCode = newRole === 'admin' 
      ? `ADMIN-${newLabel.replace(/\s+/g, '-').toUpperCase()}-${randomSuffix}`
      : `USMAN-${newLabel.replace(/\s+/g, '-').toUpperCase()}-${randomSuffix}`;

    onGenerateToken({
      token: generatedCode,
      label: newLabel,
      issuedTo: newClient,
      role: newRole,
      usageLimit: Number(newLimit) || 100,
      status: 'active',
      expiresAt: '2026-12-31',
    });

    setIsGenerating(false);
    setNewLabel('');
    setNewClient('');
  };

  const handleReconnect = () => {
    setIsReconnecting(true);
    setTimeout(() => {
      onRefreshSession();
      setIsReconnecting(false);
    }, 1500);
  };

  return (
    <div className="space-y-8">
      {/* Session Connection Card */}
      <div className="bg-white rounded-2xl p-6 md:p-8 shadow-[0_4px_25px_-5px_rgba(0,0,0,0.05)] border border-gray-100">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-gray-100 mb-6">
          <div>
            <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-brand" />
              <span>Active WhatsApp Baileys Multi-Device Socket</span>
            </h3>
            <p className="text-xs text-gray-500">
              End-to-end persistent session bridge for automated group status broadcasting
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleReconnect}
              disabled={isReconnecting}
              className="px-3.5 py-2 rounded-xl bg-gray-50 hover:bg-gray-100 text-gray-700 border border-gray-200 text-xs font-semibold flex items-center gap-1.5 transition"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-brand ${isReconnecting ? 'animate-spin' : ''}`} />
              <span>{isReconnecting ? 'Verifying Socket...' : 'Check Health'}</span>
            </button>

            <button
              onClick={() => setShowQrModal(true)}
              className="px-4 py-2 rounded-xl bg-brand hover:bg-brand-dark text-white text-xs font-bold flex items-center gap-1.5 transition shadow-sm"
            >
              <QrCode className="w-4 h-4" />
              <span>Pair Device QR</span>
            </button>
          </div>
        </div>

        {/* Live Device Info Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-emerald-50/60 border border-emerald-200/80">
            <span className="text-[10px] uppercase font-bold text-emerald-800 tracking-wider">Socket Status</span>
            <div className="text-base font-bold text-emerald-900 flex items-center gap-2 mt-1">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
              Connected & Ready
            </div>
            <span className="text-[11px] text-emerald-700 mt-1 block">
              Multi-Device v2 protocol
            </span>
          </div>

          <div className="p-4 rounded-xl bg-gray-50 border border-gray-200">
            <span className="text-[10px] uppercase font-bold text-gray-500 tracking-wider">Linked Account</span>
            <div className="text-base font-bold text-gray-900 mt-1">{session.userName}</div>
            <span className="text-[11px] font-mono text-gray-500 mt-1 block">
              {session.userPhone}
            </span>
          </div>

          <div className="p-4 rounded-xl bg-gray-50 border border-gray-200">
            <span className="text-[10px] uppercase font-bold text-gray-500 tracking-wider">Session Key / Role</span>
            <div className="text-base font-bold text-gray-900 mt-1 flex items-center gap-1.5">
              <KeyRound className="w-4 h-4 text-brand" />
              <span className="capitalize">{session.role} Role</span>
            </div>
            <span className="text-[11px] font-mono text-brand font-semibold mt-1 block truncate">
              {session.token}
            </span>
          </div>

          <div className="p-4 rounded-xl bg-gray-50 border border-gray-200">
            <span className="text-[10px] uppercase font-bold text-gray-500 tracking-wider">Device Telemetry</span>
            <div className="text-base font-bold text-gray-900 mt-1 flex items-center gap-1.5">
              <BatteryCharging className="w-4 h-4 text-emerald-600" />
              <span>{session.batteryLevel}% Charged</span>
            </div>
            <span className="text-[11px] text-gray-500 mt-1 block">
              WA Web {session.waWebVersion}
            </span>
          </div>
        </div>
      </div>

      {/* Multi-Tenant Token Administrator */}
      <div className="bg-white rounded-2xl p-6 md:p-8 shadow-[0_4px_25px_-5px_rgba(0,0,0,0.05)] border border-gray-100">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-gray-100 mb-6">
          <div>
            <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
              <Lock className="w-5 h-5 text-brand" />
              <span>Token-Gated Multi-User Access Management</span>
            </h3>
            <p className="text-xs text-gray-500">
              Generate single-use or multi-user access keys for team members, clients, and automated bots
            </p>
          </div>

          <button
            onClick={() => setIsGenerating(true)}
            className="px-4 py-2 rounded-xl bg-brand hover:bg-brand-dark text-white text-xs font-bold flex items-center gap-1.5 transition shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Generate Access Token</span>
          </button>
        </div>

        {/* Tokens Table */}
        <div className="overflow-x-auto rounded-xl border border-gray-200/80">
          <table className="w-full text-left text-xs">
            <thead className="bg-gray-50/90 text-gray-500 font-bold uppercase tracking-wider text-[10px] border-b border-gray-200">
              <tr>
                <th className="py-3.5 px-4">Token Code</th>
                <th className="py-3.5 px-4">Label & Client</th>
                <th className="py-3.5 px-4">Role</th>
                <th className="py-3.5 px-4">Usage & Quotas</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {tokens.map(t => {
                const isCurrent = session.token === t.token;
                return (
                  <tr key={t.id} className={`hover:bg-gray-50/80 transition-colors ${isCurrent ? 'bg-brand/5' : ''}`}>
                    <td className="py-3.5 px-4 font-mono font-bold text-gray-900">
                      <div className="flex items-center gap-2">
                        <span>{t.token}</span>
                        <button
                          onClick={() => handleCopy(t.token)}
                          className="text-gray-400 hover:text-brand transition"
                          title="Copy Token"
                        >
                          {copiedToken === t.token ? (
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                        {isCurrent && (
                          <span className="text-[10px] bg-brand text-white px-2 py-0.5 rounded-full font-sans font-bold">
                            Current
                          </span>
                        )}
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-gray-800">{t.label}</div>
                      <div className="text-[11px] text-gray-500">{t.issuedTo}</div>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        t.role === 'admin' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800'
                      }`}>
                        {t.role}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="text-gray-900 font-semibold">
                        {t.usedCount} / {t.usageLimit} broadcasts
                      </div>
                      <div className="w-24 bg-gray-200 rounded-full h-1.5 mt-1 overflow-hidden">
                        <div 
                          className="bg-brand h-full rounded-full" 
                          style={{ width: `${Math.min(100, (t.usedCount / t.usageLimit) * 100)}%` }}
                        ></div>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className={`inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full ${
                        t.status === 'active' 
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                          : 'bg-rose-50 text-rose-700 border border-rose-200'
                      }`}>
                        {t.status}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        {!isCurrent && (
                          <button
                            onClick={() => onSwitchToken(t.token)}
                            className="px-2.5 py-1 bg-gray-100 hover:bg-brand hover:text-white rounded text-[11px] font-semibold transition"
                          >
                            Switch To
                          </button>
                        )}
                        {tokens.length > 1 && (
                          <button
                            onClick={() => onRevokeToken(t.id)}
                            className="p-1 text-gray-400 hover:text-rose-600 rounded transition"
                            title="Revoke Token"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Generate Token Modal */}
      {isGenerating && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-gray-100">
            <h3 className="text-lg font-bold text-gray-900 mb-1">Issue New Access Token</h3>
            <p className="text-xs text-gray-500 mb-4">
              Set quota limits and credentials for a new team member or client
            </p>

            <form onSubmit={handleCreateToken} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Token Label / Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. VIP Affiliate Marketing"
                  value={newLabel}
                  onChange={(e) => setNewLabel(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs focus:outline-none focus:ring-2 focus:ring-brand/40"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Client / Assigned User Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Alex Henderson"
                  value={newClient}
                  onChange={(e) => setNewClient(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs focus:outline-none focus:ring-2 focus:ring-brand/40"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Broadcast Quota</label>
                  <input
                    type="number"
                    value={newLimit}
                    onChange={(e) => setNewLimit(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Permission Role</label>
                  <select
                    value={newRole}
                    onChange={(e) => setNewRole(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs focus:outline-none"
                  >
                    <option value="user">User (Posting Only)</option>
                    <option value="admin">Admin (Full Control)</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setIsGenerating(false)}
                  className="px-4 py-2 text-xs font-semibold text-gray-600 hover:bg-gray-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-brand hover:bg-brand-dark rounded-lg shadow-sm"
                >
                  Generate Token Key
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* QR Code Linking Simulator Modal */}
      {showQrModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 text-center shadow-2xl border border-gray-100">
            <h3 className="text-lg font-bold text-gray-900 mb-1">Scan WhatsApp QR Code</h3>
            <p className="text-xs text-gray-500 mb-4">
              Open WhatsApp on your phone → Linked Devices → Link a Device
            </p>

            <div className="w-56 h-56 mx-auto bg-gray-900 rounded-2xl p-4 flex flex-col items-center justify-center relative overflow-hidden shadow-inner mb-4">
              {/* Simulated QR Pattern */}
              <div className="grid grid-cols-6 gap-1.5 w-44 h-44 bg-white p-2 rounded-xl">
                {Array.from({ length: 36 }).map((_, i) => (
                  <div 
                    key={i} 
                    className={`rounded-xs ${
                      i === 0 || i === 5 || i === 30 || (i * 7) % 3 === 0 ? 'bg-gray-900' : 'bg-brand'
                    }`}
                  ></div>
                ))}
              </div>
              <div className="absolute inset-0 border-2 border-emerald-400/80 rounded-2xl pointer-events-none animate-pulse"></div>
            </div>

            <p className="text-[11px] text-gray-500 mb-4">
              Auto-refreshing cryptographic Baileys handshake key in 18s...
            </p>

            <button
              onClick={() => setShowQrModal(false)}
              className="w-full py-2.5 bg-brand hover:bg-brand-dark text-white rounded-xl text-xs font-bold transition shadow-sm"
            >
              Session Connected
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
