import React from 'react';
import { X, Check, Sparkles, Shield, Zap } from 'lucide-react';

interface PricingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTokenPreset: (token: string) => void;
}

export const PricingModal: React.FC<PricingModalProps> = ({ isOpen, onClose, onSelectTokenPreset }) => {
  if (!isOpen) return null;

  const tiers = [
    {
      name: 'Standard Token',
      price: '$19',
      period: '/mo',
      badge: 'Popular for Affiliates',
      tokenCode: 'USMAN-PRO-DEMO-2026',
      features: [
        'Up to 100 Group Status broadcasts/day',
        'Text + 18 color backgrounds',
        'Image & Voice note support',
        'Direct DM Daily Reports at 08:00 AM',
        'JID exclusion list (up to 25 groups)',
      ],
      ctaText: 'Use Demo Token',
      popular: false,
    },
    {
      name: 'Agency VIP',
      price: '$49',
      period: '/mo',
      badge: 'Best Value',
      tokenCode: 'USMAN-VIP-9941',
      features: [
        '500 Group Status broadcasts/day',
        'High-definition Video status encoding',
        'Unlimited group JID targeting & exclusions',
        'Live Read Receipts & Viewer Analytics',
        'Instant DM notification on replies',
        'Dedicated WhatsApp socket priority',
      ],
      ctaText: 'Use VIP Token',
      popular: true,
    },
    {
      name: 'Master Admin',
      price: 'Custom',
      period: '',
      badge: 'Enterprise Control',
      tokenCode: 'ADMIN-SUPER-KEY',
      features: [
        'Unlimited multi-tenant user tokens',
        'Admin token generation studio',
        'Multi-session WhatsApp instance switcher',
        'Full Webhook & REST API access',
        '24/7 Priority engineering DM hotline',
      ],
      ctaText: 'Unlock Admin Mode',
      popular: false,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-2xl max-w-4xl w-full p-6 md:p-8 shadow-2xl border border-gray-100 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-4 border-b border-gray-100 mb-6">
          <div>
            <span className="text-xs font-bold text-brand uppercase tracking-wider">Pricing & Licensing</span>
            <h3 className="text-2xl font-bold text-gray-900">Token Plans for Every Team</h3>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-gray-700 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          {tiers.map((tier, idx) => (
            <div 
              key={idx} 
              className={`rounded-2xl p-6 flex flex-col justify-between transition-all relative ${
                tier.popular 
                  ? 'bg-brand/5 border-2 border-brand shadow-lg' 
                  : 'bg-gray-50 border border-gray-200/80 hover:bg-white hover:shadow-md'
              }`}
            >
              {tier.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-brand text-white text-[11px] font-bold py-1 px-3 rounded-full flex items-center gap-1 shadow-sm">
                  <Sparkles className="w-3 h-3" /> {tier.badge}
                </div>
              )}

              <div>
                <h4 className="font-bold text-gray-900 text-lg mb-1">{tier.name}</h4>
                <div className="flex items-baseline gap-1 mb-4">
                  <span className="text-3xl font-extrabold text-gray-900">{tier.price}</span>
                  <span className="text-xs text-gray-500">{tier.period}</span>
                </div>

                <ul className="space-y-2.5 mb-6 text-xs text-gray-600">
                  {tier.features.map((feat, fIdx) => (
                    <li key={fIdx} className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <button
                onClick={() => {
                  onSelectTokenPreset(tier.tokenCode);
                  onClose();
                }}
                className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold transition-all shadow-sm flex items-center justify-center gap-1.5 ${
                  tier.popular
                    ? 'bg-brand hover:bg-brand-dark text-white'
                    : 'bg-white hover:bg-gray-100 text-gray-800 border border-gray-300'
                }`}
              >
                <Zap className="w-3.5 h-3.5" />
                {tier.ctaText}
              </button>
            </div>
          ))}
        </div>

        <div className="text-center text-xs text-gray-400">
          Need a customized multi-agent server deployment? Contact Usman support directly on WhatsApp.
        </div>
      </div>
    </div>
  );
};
