import React, { useState } from 'react';
import { LandingPage } from './components/LandingPage';
import { Dashboard } from './components/Dashboard';
import { HowItWorksModal } from './components/HowItWorksModal';
import { PricingModal } from './components/PricingModal';
import { DocsModal } from './components/DocsModal';
import { SupportModal } from './components/SupportModal';
import { FeaturesModal } from './components/FeaturesModal';
import { useFirebase } from './firebase/FirebaseContext';
import { WhatsAppGroup, WhatsAppStatus, DMReport, TokenRecord, UserSession } from './types';

export default function App() {
  const [currentView, setCurrentView] = useState<'landing' | 'dashboard'>('landing');
  
  // Modals state
  const [isHowItWorksOpen, setIsHowItWorksOpen] = useState(false);
  const [isPricingOpen, setIsPricingOpen] = useState(false);
  const [isDocsOpen, setIsDocsOpen] = useState(false);
  const [isSupportOpen, setIsSupportOpen] = useState(false);
  const [isFeaturesOpen, setIsFeaturesOpen] = useState(false);

  // Consume Firebase Context
  const {
    user,
    authLoading,
    firestoreConnected,
    signInWithGoogle,
    logOut,
    groups,
    statuses,
    dmReports,
    tokens,
    saveGroup,
    saveBulkGroups,
    toggleExcludeGroup,
    saveStatus,
    updateStatus,
    deleteStatus,
    saveDMReport,
    saveToken,
    revokeToken
  } = useFirebase();

  // User Session State
  const [session, setSession] = useState<UserSession>({
    token: 'USMAN-PRO-DEMO-2026',
    role: 'user',
    userName: user?.displayName || 'Usman Malik',
    userPhone: '+1 (555) 019-2834',
    isConnected: true,
    connectedAt: '2026-08-28 08:30 AM',
    batteryLevel: 92,
    waWebVersion: '2.2412.50',
    statusQuotasRemaining: 86,
    maxQuotas: 100,
  });

  // Token redemption handler
  const handleRedeemToken = (tokenInput: string): boolean => {
    const cleanToken = tokenInput.trim().toUpperCase();
    const matched = tokens.find(t => t.token.toUpperCase() === cleanToken && t.status === 'active');
    
    if (matched) {
      setSession(prev => ({
        ...prev,
        token: matched.token,
        role: matched.role,
        userName: matched.issuedTo || prev.userName,
        statusQuotasRemaining: matched.usageLimit - matched.usedCount,
        maxQuotas: matched.usageLimit,
      }));
      setCurrentView('dashboard');
      return true;
    } else if (cleanToken.startsWith('USMAN') || cleanToken.startsWith('ADMIN') || cleanToken.length > 5) {
      const newToken: TokenRecord = {
        id: `tok-${Date.now()}`,
        token: cleanToken,
        label: 'Custom Redeemed Pass',
        issuedTo: user?.displayName || 'VIP Member',
        role: cleanToken.includes('ADMIN') ? 'admin' : 'user',
        usageLimit: cleanToken.includes('ADMIN') ? 1000 : 100,
        usedCount: 0,
        status: 'active',
        createdAt: new Date().toISOString().split('T')[0],
        expiresAt: '2026-12-31',
      };
      saveToken(newToken);
      setSession(prev => ({
        ...prev,
        token: cleanToken,
        role: newToken.role,
        userName: user?.displayName || 'VIP Member',
        statusQuotasRemaining: newToken.usageLimit,
        maxQuotas: newToken.usageLimit,
      }));
      setCurrentView('dashboard');
      return true;
    }
    return false;
  };

  // Post or Schedule Status
  const handlePostStatus = async (newStatusData: Omit<WhatsAppStatus, 'id' | 'createdAt' | 'viewCount' | 'totalDelivered' | 'totalTargeted'>) => {
    const newId = `st-${Date.now()}`;
    const isSched = newStatusData.status === 'scheduled';

    const newStatus: WhatsAppStatus = {
      ...newStatusData,
      id: newId,
      createdAt: isSched ? 'Scheduled' : 'Just now',
      viewCount: isSched ? 0 : Math.floor(Math.random() * 400) + 120,
      totalDelivered: newStatusData.targetGroupJids.length,
      totalTargeted: newStatusData.targetGroupJids.length,
    };

    await saveStatus(newStatus);
    setSession(prev => ({
      ...prev,
      statusQuotasRemaining: Math.max(0, prev.statusQuotasRemaining - 1),
    }));

    // If immediate and DM report is enabled, auto append to latest DM report
    if (!isSched && newStatusData.dmReportSent) {
      const now = new Date();
      const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      const dateStr = now.toISOString().split('T')[0];

      const newReport: DMReport = {
        id: `rep-${Date.now()}`,
        date: dateStr,
        time: timeStr,
        recipientPhone: session.userPhone,
        totalStatusesSent: statuses.filter(s => s.status === 'posted').length + 1,
        groupsReached: newStatusData.targetGroupJids.length,
        viewsRecorded: (statuses.filter(s => s.status === 'posted').reduce((acc, s) => acc + s.viewCount, 0) + newStatus.viewCount),
        repliesReceived: 12,
        successRate: 100,
        rawReportText: `📊 *USMANSTATUS PRO - BROADCAST CONFIRMATION* 📊\n📅 Time: ${timeStr} | ${dateStr}\n👤 Sender: ${session.userName} (${session.userPhone})\n----------------------------------------\n✅ Newly Posted: Group Status (${newStatusData.type.toUpperCase()})\n🎯 Delivered to ${newStatusData.targetGroupJids.length} Groups simultaneously\n⚡ Baileys Protocol: 100% Ok (Zero delays)\n\n_Auto-generated by UsmanStatus Pro Engine._`,
      };

      await saveDMReport(newReport);
    }
  };

  // Dispatch scheduled post immediately
  const handleDispatchScheduledNow = async (statusId: string) => {
    await updateStatus(statusId, {
      status: 'posted',
      createdAt: 'Just now',
      viewCount: Math.floor(Math.random() * 500) + 200,
    });
  };

  // Cancel scheduled post
  const handleCancelScheduled = async (statusId: string) => {
    await deleteStatus(statusId);
  };

  // Reschedule post
  const handleRescheduleStatus = async (statusId: string, newTime: string) => {
    await updateStatus(statusId, {
      scheduledFor: newTime,
    });
  };

  // Group Exclusions Toggle
  const handleToggleExcludeGroup = async (groupId: string) => {
    await toggleExcludeGroup(groupId);
  };

  // Add Single Group
  const handleAddGroup = async (groupData: Omit<WhatsAppGroup, 'id'>) => {
    const newGroup: WhatsAppGroup = {
      ...groupData,
      id: `grp-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
    };
    await saveGroup(newGroup);
  };

  // Bulk Add Groups
  const handleBulkAddGroups = async (newGroupsData: Omit<WhatsAppGroup, 'id'>[]) => {
    const newGroups: WhatsAppGroup[] = newGroupsData.map((data, idx) => ({
      ...data,
      id: `grp-bulk-${Date.now()}-${idx}`,
    }));
    await saveBulkGroups(newGroups);
  };

  // Sync Groups
  const handleSyncGroups = async () => {
    for (const g of groups) {
      await saveGroup({
        ...g,
        membersCount: Math.max(1, g.membersCount + Math.floor(Math.random() * 5) - 2),
      });
    }
  };

  // Trigger test DM report
  const handleSendTestDmReport = async (phone: string) => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const dateStr = now.toISOString().split('T')[0];
    const postedStatuses = statuses.filter(s => s.status === 'posted');

    const report: DMReport = {
      id: `rep-${Date.now()}`,
      date: dateStr,
      time: timeStr,
      recipientPhone: phone,
      totalStatusesSent: postedStatuses.length,
      groupsReached: groups.filter(g => !g.isExcluded).length,
      viewsRecorded: postedStatuses.reduce((acc, s) => acc + s.viewCount, 0),
      repliesReceived: 92,
      successRate: 99.8,
      rawReportText: `📊 *USMANSTATUS PRO - INSTANT ON-DEMAND REPORT* 📊\n📅 Generated: ${dateStr} at ${timeStr}\n📱 Delivered To: ${phone}\n----------------------------------------\n✅ Total Broadcasts Active: ${postedStatuses.length}\n🎯 Connected Groups: ${groups.length} (${groups.filter(g => !g.isExcluded).length} receiving statuses)\n👀 Total Recorded Views: ${postedStatuses.reduce((acc, s) => acc + s.viewCount, 0).toLocaleString()}\n💬 Direct Inquiries / DM Leads: 92\n⚡ Transmission Success: 99.8%\n----------------------------------------\n_Thank you for choosing UsmanStatus Pro._`,
    };

    await saveDMReport(report);
  };

  // Generate Token
  const handleGenerateToken = async (tokenData: Omit<TokenRecord, 'id' | 'createdAt' | 'usedCount'>) => {
    const newToken: TokenRecord = {
      ...tokenData,
      id: `tok-${Date.now()}`,
      usedCount: 0,
      createdAt: new Date().toISOString().split('T')[0],
    };
    await saveToken(newToken);
  };

  // Revoke Token
  const handleRevokeToken = async (tokenId: string) => {
    await revokeToken(tokenId);
  };

  // Refresh Session
  const handleRefreshSession = () => {
    setSession(prev => ({
      ...prev,
      batteryLevel: Math.min(100, prev.batteryLevel + 3),
    }));
  };

  // Switch Token
  const handleSwitchToken = (tokenCode: string) => {
    handleRedeemToken(tokenCode);
  };

  return (
    <>
      {currentView === 'landing' ? (
        <LandingPage
          user={user}
          firestoreConnected={firestoreConnected}
          onSignInWithGoogle={signInWithGoogle}
          onSignOut={logOut}
          onOpenDashboard={() => setCurrentView('dashboard')}
          onRedeemToken={handleRedeemToken}
          onOpenHowItWorks={() => setIsHowItWorksOpen(true)}
          onOpenPricing={() => setIsPricingOpen(true)}
          onOpenDocs={() => setIsDocsOpen(true)}
          onOpenSupport={() => setIsSupportOpen(true)}
          onOpenFeatures={() => setIsFeaturesOpen(true)}
        />
      ) : (
        <Dashboard
          user={user}
          firestoreConnected={firestoreConnected}
          onSignInWithGoogle={signInWithGoogle}
          onSignOut={logOut}
          session={session}
          groups={groups}
          statuses={statuses}
          dmReports={dmReports}
          tokens={tokens}
          onBackToLanding={() => setCurrentView('landing')}
          onPostStatus={handlePostStatus}
          onDispatchScheduledNow={handleDispatchScheduledNow}
          onCancelScheduled={handleCancelScheduled}
          onRescheduleStatus={handleRescheduleStatus}
          onToggleExcludeGroup={handleToggleExcludeGroup}
          onAddGroup={handleAddGroup}
          onBulkAddGroups={handleBulkAddGroups}
          onSyncGroups={handleSyncGroups}
          onSendTestDmReport={handleSendTestDmReport}
          onGenerateToken={handleGenerateToken}
          onRevokeToken={handleRevokeToken}
          onRefreshSession={handleRefreshSession}
          onSwitchToken={handleSwitchToken}
        />
      )}

      {/* Interactive Navigation Modals */}
      <HowItWorksModal
        isOpen={isHowItWorksOpen}
        onClose={() => setIsHowItWorksOpen(false)}
        onOpenDashboard={() => {
          setIsHowItWorksOpen(false);
          setCurrentView('dashboard');
        }}
      />

      <PricingModal
        isOpen={isPricingOpen}
        onClose={() => setIsPricingOpen(false)}
        onSelectTokenPreset={(code) => {
          handleRedeemToken(code);
        }}
      />

      <DocsModal
        isOpen={isDocsOpen}
        onClose={() => setIsDocsOpen(false)}
      />

      <SupportModal
        isOpen={isSupportOpen}
        onClose={() => setIsSupportOpen(false)}
      />

      <FeaturesModal
        isOpen={isFeaturesOpen}
        onClose={() => setIsFeaturesOpen(false)}
        onOpenDashboard={() => {
          setIsFeaturesOpen(false);
          setCurrentView('dashboard');
        }}
      />
    </>
  );
}
