import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { 
  User, 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged,
  signInAnonymously
} from 'firebase/auth';
import { 
  collection, 
  doc, 
  setDoc, 
  deleteDoc, 
  onSnapshot, 
  writeBatch
} from 'firebase/firestore';
import { auth, db, googleProvider, handleFirestoreError, OperationType, testConnection } from './config';
import { WhatsAppGroup, WhatsAppStatus, DMReport, TokenRecord } from '../types';
import { INITIAL_GROUPS, INITIAL_STATUSES, INITIAL_DM_REPORTS, INITIAL_TOKENS } from '../data/mockData';

interface FirebaseContextType {
  user: User | null;
  authLoading: boolean;
  isFirebaseReady: boolean;
  firestoreConnected: boolean;
  signInWithGoogle: () => Promise<void>;
  signInAsGuest: () => Promise<void>;
  logOut: () => Promise<void>;
  // Firestore Persistence methods
  groups: WhatsAppGroup[];
  statuses: WhatsAppStatus[];
  dmReports: DMReport[];
  tokens: TokenRecord[];
  saveGroup: (group: WhatsAppGroup) => Promise<void>;
  saveBulkGroups: (newGroups: WhatsAppGroup[]) => Promise<void>;
  deleteGroup: (groupId: string) => Promise<void>;
  toggleExcludeGroup: (groupId: string) => Promise<void>;
  saveStatus: (status: WhatsAppStatus) => Promise<void>;
  updateStatus: (statusId: string, updates: Partial<WhatsAppStatus>) => Promise<void>;
  deleteStatus: (statusId: string) => Promise<void>;
  saveDMReport: (report: DMReport) => Promise<void>;
  saveToken: (token: TokenRecord) => Promise<void>;
  revokeToken: (tokenId: string) => Promise<void>;
  syncDataNow: () => Promise<void>;
}

const FirebaseContext = createContext<FirebaseContextType | undefined>(undefined);

export const FirebaseProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState<boolean>(true);
  const [isFirebaseReady, setIsFirebaseReady] = useState<boolean>(false);
  const [firestoreConnected, setFirestoreConnected] = useState<boolean>(false);

  // Synced states
  const [groups, setGroups] = useState<WhatsAppGroup[]>(INITIAL_GROUPS);
  const [statuses, setStatuses] = useState<WhatsAppStatus[]>(INITIAL_STATUSES);
  const [dmReports, setDmReports] = useState<DMReport[]>(INITIAL_DM_REPORTS);
  const [tokens, setTokens] = useState<TokenRecord[]>(INITIAL_TOKENS);

  // Test connection on mount
  useEffect(() => {
    testConnection().then(ok => setFirestoreConnected(ok));
  }, []);

  // Listen to Auth State
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setAuthLoading(false);
      setIsFirebaseReady(true);

      if (currentUser) {
        try {
          const idToken = await currentUser.getIdToken();
          await fetch('/api/auth/sync', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${idToken}`,
            },
          });
        } catch (err) {
          console.warn('Cloud SQL backend user sync note:', err);
        }
      }
    });

    return () => unsubscribe();
  }, []);

  // Real-time Firestore Synchronizers when user is signed in
  useEffect(() => {
    if (!user) {
      // If logged out, retain initial default datasets
      setGroups(INITIAL_GROUPS);
      setStatuses(INITIAL_STATUSES);
      setDmReports(INITIAL_DM_REPORTS);
      setTokens(INITIAL_TOKENS);
      return;
    }

    const uid = user.uid;

    // 1. Synchronize Groups
    const groupsPath = `users/${uid}/groups`;
    const unsubGroups = onSnapshot(
      collection(db, groupsPath),
      async (snapshot) => {
        if (snapshot.empty) {
          // First time user: Seed with starter groups
          try {
            const batch = writeBatch(db);
            INITIAL_GROUPS.forEach(g => {
              const ref = doc(db, groupsPath, g.id);
              batch.set(ref, { ...g, userId: uid });
            });
            await batch.commit();
          } catch (err) {
            console.error('Error seeding groups:', err);
          }
        } else {
          const loaded: WhatsAppGroup[] = snapshot.docs.map(d => d.data() as WhatsAppGroup);
          setGroups(loaded);
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, groupsPath);
      }
    );

    // 2. Synchronize Statuses
    const statusesPath = `users/${uid}/statuses`;
    const unsubStatuses = onSnapshot(
      collection(db, statusesPath),
      async (snapshot) => {
        if (snapshot.empty) {
          try {
            const batch = writeBatch(db);
            INITIAL_STATUSES.forEach(s => {
              const ref = doc(db, statusesPath, s.id);
              batch.set(ref, { ...s, userId: uid });
            });
            await batch.commit();
          } catch (err) {
            console.error('Error seeding statuses:', err);
          }
        } else {
          const loaded: WhatsAppStatus[] = snapshot.docs.map(d => d.data() as WhatsAppStatus);
          setStatuses(loaded);
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, statusesPath);
      }
    );

    // 3. Synchronize DM Reports
    const dmReportsPath = `users/${uid}/dmReports`;
    const unsubReports = onSnapshot(
      collection(db, dmReportsPath),
      async (snapshot) => {
        if (snapshot.empty) {
          try {
            const batch = writeBatch(db);
            INITIAL_DM_REPORTS.forEach(r => {
              const ref = doc(db, dmReportsPath, r.id);
              batch.set(ref, { ...r, userId: uid });
            });
            await batch.commit();
          } catch (err) {
            console.error('Error seeding dmReports:', err);
          }
        } else {
          const loaded: DMReport[] = snapshot.docs.map(d => d.data() as DMReport);
          setDmReports(loaded);
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, dmReportsPath);
      }
    );

    // 4. Synchronize Tokens
    const tokensPath = `users/${uid}/tokens`;
    const unsubTokens = onSnapshot(
      collection(db, tokensPath),
      async (snapshot) => {
        if (snapshot.empty) {
          try {
            const batch = writeBatch(db);
            INITIAL_TOKENS.forEach(t => {
              const ref = doc(db, tokensPath, t.id);
              batch.set(ref, { ...t, userId: uid });
            });
            await batch.commit();
          } catch (err) {
            console.error('Error seeding tokens:', err);
          }
        } else {
          const loaded: TokenRecord[] = snapshot.docs.map(d => d.data() as TokenRecord);
          setTokens(loaded);
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, tokensPath);
      }
    );

    return () => {
      unsubGroups();
      unsubStatuses();
      unsubReports();
      unsubTokens();
    };
  }, [user]);

  // Auth Functions
  const signInWithGoogle = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      console.error('Google Sign In Error:', err);
      throw err;
    }
  };

  const signInAsGuest = async () => {
    try {
      await signInAnonymously(auth);
    } catch (err) {
      console.error('Guest Auth Error:', err);
      throw err;
    }
  };

  const logOut = async () => {
    try {
      await signOut(auth);
    } catch (err) {
      console.error('Sign Out Error:', err);
    }
  };

  // Group persistence
  const saveGroup = async (group: WhatsAppGroup) => {
    if (user) {
      const path = `users/${user.uid}/groups/${group.id}`;
      try {
        await setDoc(doc(db, 'users', user.uid, 'groups', group.id), {
          ...group,
          userId: user.uid,
          updatedAt: new Date().toISOString()
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, path);
      }
    } else {
      setGroups(prev => [group, ...prev.filter(g => g.id !== group.id)]);
    }
  };

  const saveBulkGroups = async (newGroups: WhatsAppGroup[]) => {
    if (user) {
      try {
        const batch = writeBatch(db);
        newGroups.forEach(g => {
          const ref = doc(db, 'users', user.uid, 'groups', g.id);
          batch.set(ref, { ...g, userId: user.uid, updatedAt: new Date().toISOString() });
        });
        await batch.commit();
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}/groups`);
      }
    } else {
      setGroups(prev => [...newGroups, ...prev]);
    }
  };

  const deleteGroup = async (groupId: string) => {
    if (user) {
      const path = `users/${user.uid}/groups/${groupId}`;
      try {
        await deleteDoc(doc(db, 'users', user.uid, 'groups', groupId));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, path);
      }
    } else {
      setGroups(prev => prev.filter(g => g.id !== groupId));
    }
  };

  const toggleExcludeGroup = async (groupId: string) => {
    const target = groups.find(g => g.id === groupId);
    if (!target) return;
    const updated = { ...target, isExcluded: !target.isExcluded };
    await saveGroup(updated);
  };

  // Status persistence
  const saveStatus = async (status: WhatsAppStatus) => {
    if (user) {
      const path = `users/${user.uid}/statuses/${status.id}`;
      try {
        await setDoc(doc(db, 'users', user.uid, 'statuses', status.id), {
          ...status,
          userId: user.uid,
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, path);
      }
    } else {
      setStatuses(prev => [status, ...prev.filter(s => s.id !== status.id)]);
    }
  };

  const updateStatus = async (statusId: string, updates: Partial<WhatsAppStatus>) => {
    const existing = statuses.find(s => s.id === statusId);
    if (!existing) return;
    const updated = { ...existing, ...updates };
    await saveStatus(updated);
  };

  const deleteStatus = async (statusId: string) => {
    if (user) {
      const path = `users/${user.uid}/statuses/${statusId}`;
      try {
        await deleteDoc(doc(db, 'users', user.uid, 'statuses', statusId));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, path);
      }
    } else {
      setStatuses(prev => prev.filter(s => s.id !== statusId));
    }
  };

  // DM Report persistence
  const saveDMReport = async (report: DMReport) => {
    if (user) {
      const path = `users/${user.uid}/dmReports/${report.id}`;
      try {
        await setDoc(doc(db, 'users', user.uid, 'dmReports', report.id), {
          ...report,
          userId: user.uid,
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, path);
      }
    } else {
      setDmReports(prev => [report, ...prev.filter(r => r.id !== report.id)]);
    }
  };

  // Token persistence
  const saveToken = async (token: TokenRecord) => {
    if (user) {
      const path = `users/${user.uid}/tokens/${token.id}`;
      try {
        await setDoc(doc(db, 'users', user.uid, 'tokens', token.id), {
          ...token,
          userId: user.uid,
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, path);
      }
    } else {
      setTokens(prev => [token, ...prev.filter(t => t.id !== token.id)]);
    }
  };

  const revokeToken = async (tokenId: string) => {
    if (user) {
      const path = `users/${user.uid}/tokens/${tokenId}`;
      try {
        await deleteDoc(doc(db, 'users', user.uid, 'tokens', tokenId));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, path);
      }
    } else {
      setTokens(prev => prev.filter(t => t.id !== tokenId));
    }
  };

  const syncDataNow = async () => {
    await testConnection();
  };

  return (
    <FirebaseContext.Provider
      value={{
        user,
        authLoading,
        isFirebaseReady,
        firestoreConnected,
        signInWithGoogle,
        signInAsGuest,
        logOut,
        groups,
        statuses,
        dmReports,
        tokens,
        saveGroup,
        saveBulkGroups,
        deleteGroup,
        toggleExcludeGroup,
        saveStatus,
        updateStatus,
        deleteStatus,
        saveDMReport,
        saveToken,
        revokeToken,
        syncDataNow
      }}
    >
      {children}
    </FirebaseContext.Provider>
  );
};

export const useFirebase = (): FirebaseContextType => {
  const context = useContext(FirebaseContext);
  if (!context) {
    throw new Error('useFirebase must be used within a FirebaseProvider');
  }
  return context;
};
