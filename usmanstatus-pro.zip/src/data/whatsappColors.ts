import { ColorPreset } from '../types';

export const WHATSAPP_18_COLORS: ColorPreset[] = [
  { id: '1', name: 'Electric Purple', hex: '#7356bf', textColor: '#ffffff' },
  { id: '2', name: 'Emerald WhatsApp', hex: '#075e54', textColor: '#ffffff' },
  { id: '3', name: 'Teal Green', hex: '#128c7e', textColor: '#ffffff' },
  { id: '4', name: 'Crimson Rose', hex: '#cf2b56', textColor: '#ffffff' },
  { id: '5', name: 'Vibrant Orange', hex: '#ff7638', textColor: '#ffffff' },
  { id: '6', name: 'Ocean Blue', hex: '#1c73e8', textColor: '#ffffff' },
  { id: '7', name: 'Sunset Amber', hex: '#ff9f00', textColor: '#ffffff' },
  { id: '8', name: 'Deep Burgundy', hex: '#581845', textColor: '#ffffff' },
  { id: '9', name: 'Olive Sage', hex: '#5f7161', textColor: '#ffffff' },
  { id: '10', name: 'Hot Bubblegum', hex: '#f43260', textColor: '#ffffff' },
  { id: '11', name: 'Dark Slate', hex: '#2d3436', textColor: '#ffffff' },
  { id: '12', name: 'Cocoa Brown', hex: '#4e342e', textColor: '#ffffff' },
  { id: '13', name: 'Royal Indigo', hex: '#283593', textColor: '#ffffff' },
  { id: '14', name: 'Lime Punch', hex: '#7cb342', textColor: '#ffffff' },
  { id: '15', name: 'Steel Cyan', hex: '#00838f', textColor: '#ffffff' },
  { id: '16', name: 'Midnight Onyx', hex: '#181818', textColor: '#ffffff' },
  { id: '17', name: 'Cobalt Blue', hex: '#1565c0', textColor: '#ffffff' },
  { id: '18', name: 'Magenta Glow', hex: '#c2185b', textColor: '#ffffff' },
];
