import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { requireAuth, AuthRequest } from './src/middleware/auth.ts';
import { getOrCreateUser } from './src/db/users.ts';
import { getUserGroups, upsertGroup, deleteUserGroup } from './src/db/groups.ts';
import { getUserStatuses, upsertStatus, deleteUserStatus } from './src/db/statuses.ts';
import { getUserReports, insertDMReport } from './src/db/reports.ts';
import { getUserTokens, upsertToken, deleteUserToken } from './src/db/tokens.ts';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', engine: 'Cloud SQL PostgreSQL + Baileys Multi-Device' });
  });

  // User synchronization & profile
  app.post('/api/auth/sync', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user!.uid;
      const email = req.user!.email || `${uid}@usmanstatus.local`;
      const displayName = (req.user as any)?.name || null;
      const dbUser = await getOrCreateUser(uid, email, displayName);
      res.json({ success: true, user: dbUser });
    } catch (error: any) {
      console.error('Failed to sync user with database:', error);
      res.status(500).json({ error: error.message || 'Failed to sync user' });
    }
  });

  // Groups API
  app.get('/api/groups', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user!.uid;
      const userGroups = await getUserGroups(uid);
      res.json(userGroups);
    } catch (error: any) {
      console.error('Failed to fetch groups:', error);
      res.status(500).json({ error: error.message || 'Failed to fetch groups' });
    }
  });

  app.post('/api/groups', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user!.uid;
      const { id, jid, name, isExcluded, membersCount, tags } = req.body;
      const saved = await upsertGroup({
        id,
        userId: uid,
        jid,
        name,
        isExcluded: Boolean(isExcluded),
        membersCount: Number(membersCount) || 0,
        tags: tags || [],
      });
      res.json(saved);
    } catch (error: any) {
      console.error('Failed to save group:', error);
      res.status(500).json({ error: error.message || 'Failed to save group' });
    }
  });

  app.delete('/api/groups/:id', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user!.uid;
      const groupId = req.params.id;
      await deleteUserGroup(groupId, uid);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to delete group:', error);
      res.status(500).json({ error: error.message || 'Failed to delete group' });
    }
  });

  // Statuses API
  app.get('/api/statuses', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user!.uid;
      const userStatuses = await getUserStatuses(uid);
      res.json(userStatuses);
    } catch (error: any) {
      console.error('Failed to fetch statuses:', error);
      res.status(500).json({ error: error.message || 'Failed to fetch statuses' });
    }
  });

  app.post('/api/statuses', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user!.uid;
      const statusData = req.body;
      const saved = await upsertStatus({
        ...statusData,
        userId: uid,
      });
      res.json(saved);
    } catch (error: any) {
      console.error('Failed to save status:', error);
      res.status(500).json({ error: error.message || 'Failed to save status' });
    }
  });

  app.delete('/api/statuses/:id', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user!.uid;
      const statusId = req.params.id;
      await deleteUserStatus(statusId, uid);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to delete status:', error);
      res.status(500).json({ error: error.message || 'Failed to delete status' });
    }
  });

  // DM Reports API
  app.get('/api/reports', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user!.uid;
      const reports = await getUserReports(uid);
      res.json(reports);
    } catch (error: any) {
      console.error('Failed to fetch DM reports:', error);
      res.status(500).json({ error: error.message || 'Failed to fetch DM reports' });
    }
  });

  app.post('/api/reports', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user!.uid;
      const reportData = req.body;
      const saved = await insertDMReport({
        ...reportData,
        userId: uid,
      });
      res.json(saved);
    } catch (error: any) {
      console.error('Failed to save DM report:', error);
      res.status(500).json({ error: error.message || 'Failed to save DM report' });
    }
  });

  // Tokens API
  app.get('/api/tokens', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user!.uid;
      const userTokens = await getUserTokens(uid);
      res.json(userTokens);
    } catch (error: any) {
      console.error('Failed to fetch tokens:', error);
      res.status(500).json({ error: error.message || 'Failed to fetch tokens' });
    }
  });

  app.post('/api/tokens', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user!.uid;
      const tokenData = req.body;
      const saved = await upsertToken({
        ...tokenData,
        userId: uid,
      });
      res.json(saved);
    } catch (error: any) {
      console.error('Failed to save token:', error);
      res.status(500).json({ error: error.message || 'Failed to save token' });
    }
  });

  app.delete('/api/tokens/:id', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user!.uid;
      const tokenId = req.params.id;
      await deleteUserToken(tokenId, uid);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to delete token:', error);
      res.status(500).json({ error: error.message || 'Failed to delete token' });
    }
  });

  // Vite middleware for development vs static build for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`UsmanStatus Pro Cloud SQL Backend running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
