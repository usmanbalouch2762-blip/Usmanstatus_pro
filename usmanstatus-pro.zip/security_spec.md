# Security Specification for UsmanStatus Pro

## 1. Data Invariants
1. User-isolated data trees: All resources (`groups`, `statuses`, `dmReports`, `tokens`) are partitioned under `/users/{userId}/...` where `{userId}` must strictly match `request.auth.uid`.
2. No cross-tenant access: A user cannot read, query, list, create, update, or delete any other user's WhatsApp groups, status drafts, DM reports, or access tokens.
3. String limits & Schema conformity: Document IDs and string fields must be constrained (IDs <= 128 chars, status content <= 5000 chars, JIDs strictly formatted).
4. No ghost/unauthorized fields: Partial updates must only affect whitelisted attributes.
5. Default deny: Root match `/{document=**}` denies all access by default.

## 2. The Dirty Dozen Attack Payloads & Test Assertions
1. **Unauthenticated Read (`/users/user123/groups`)**: `request.auth = null` -> `PERMISSION_DENIED`
2. **Cross-User Group Ingestion (`/users/victim456/groups/grp1`)**: `request.auth.uid = attacker123` -> `PERMISSION_DENIED`
3. **Cross-User Status Broadcast Scraping (`/users/victim456/statuses`)**: `request.auth.uid = attacker123` -> `PERMISSION_DENIED`
4. **Forged Document Path ID Injection (`/users/user123/groups/../../root`)**: Malformed path -> `PERMISSION_DENIED`
5. **Oversized Status Payload (15MB Content Bomb)**: `content.size() > 5000` -> `PERMISSION_DENIED`
6. **Malicious JID Spoofing (`"bad-string-not-jid"`)**: `jid.matches(...) == false` -> `PERMISSION_DENIED`
7. **Privilege Escalation on Tokens (`role: 'admin'`) by regular user**: Unauthorized privilege modification -> `PERMISSION_DENIED`
8. **Direct Cross-User DM Report Interception (`/users/victim/dmReports/rep1`)**: Non-owner read -> `PERMISSION_DENIED`
9. **Blanket Query Scraping on `/users` root**: `allow list: if false` on root -> `PERMISSION_DENIED`
10. **Shadow Key Injection (`{ ghostKey: true, isSuperAdmin: true }`)**: Unvalidated key payload -> `PERMISSION_DENIED`
11. **Improper ID Poisoning (1.5KB UTF-8 ID String)**: `isValidId(id) == false` -> `PERMISSION_DENIED`
12. **Immutable Field Tampering (`createdAt` update to fake past time)**: -> `PERMISSION_DENIED`
